clc; clear;

s1 = 100;
s2 = 2000;

T_x = csvread('/home/bluesky/catkin_ws/src/bebop_ros/repo/pid/csv/cmd_pos_x_axis.csv', 1);
t_x =   T_x(s1:s2, 1);
x_cmd = T_x(s1:s2, 2);
x_pos = T_x(s1:s2, 6);
x_sp = T_x(s1:s2, 12);

plot(t_x, x_pos, t_x, x_sp)

% T_z = csvread('/home/bluesky/catkin_ws/src/bebop_ros/repo/pid/csv/cmd_pos_z_axis.csv', 1);
% t_z =   T_z(s1:s2, 1);
% z_cmd = T_z(s1:s2, 4);
% z_pos = T_z(s1:s2, 8);
% z_sp = T_z(s1:s2, 14);
% 
% 
% plot(t_z, z_pos, t_z, z_sp)