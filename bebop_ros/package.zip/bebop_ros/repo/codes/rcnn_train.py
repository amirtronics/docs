#! /usr/bin/env python

"""
Software License Agreement (BSD)

File: rcnn_train.py
Author: Amir Hossein Ebrahimnezhad ebrahimnezhad@ualberta.ca
Maintainer: Martin Barczyk mbarczyk@ualberta.ca
Copyright: Copyright (c) 2023, Mechatronic Systems Lab (University of Alberta), All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that
the following conditions are met:

Redistributions of source code must retain the above copyright notice, this list of conditions and the
following disclaimer.
Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the
following disclaimer in the documentation and/or other materials provided with the distribution.
Neither the name of Mechatronic Systems Lab nor the names of its contributors may be used to endorse or promote
products derived from this software without specific prior written permission.
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WAR-
RANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, IN-
DIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
"""

# Libraries

from distutils.log import error
import os, json, cv2, numpy as np, matplotlib.pyplot as plt

from regex import E

import torch
from torch.utils.data import Dataset, DataLoader

import torchvision
from torchvision.models.detection.rpn import AnchorGenerator
from torchvision.transforms import functional as F

import math
import sys

import random
import pandas as pd

import rospkg



## Global Variables


kp_num = 8

Resized_frame = False
Model_Train = True

rospack = rospkg.RosPack()
workspace_dir = rospack.get_path('bebop_ros')	

# if not os.path.isdir("./vision"):
#     !git clone https://github.com/pytorch/vision.git

# cwd = os.getcwd()
# os.chdir('//home/bluesky/Documents/Codes/AI/Keypoint_RCNN/vision/references/detection')

import transforms, utils, engine, train
from utils import collate_fn
from engine import train_one_epoch, evaluate

# os.chdir(cwd)

if Resized_frame:

    KEYPOINTS_FOLDER_TRAIN = '/home/bluesky/Documents/Codes/AI/Data/RCNN_Keypoints/medium/180x320/train'
    KEYPOINTS_FOLDER_TEST = '/home/bluesky/Documents/Codes/AI/Data/RCNN_Keypoints/medium/180x320/test/images'
    line_width = 1

else:

    if kp_num == 8:


        KEYPOINTS_FOLDER_TRAIN = workspace_dir + '/repo/rcnn/train'
        KEYPOINTS_FOLDER_TEST = workspace_dir + '/repo/rcnn/test/'

        line_width = 3


class ClassDataset(Dataset):
    def __init__(self, root, transform=None, demo=False):                
        self.root = root
        self.imgs_files = sorted(os.listdir(os.path.join(root, "images")))
        self.annotations_files = sorted(os.listdir(os.path.join(root, "annotations")))
    
    def __getitem__(self, idx):
        img_path = os.path.join(self.root, "images", self.imgs_files[idx])
        annotations_path = os.path.join(self.root, "annotations", self.annotations_files[idx])

        img_original = cv2.imread(img_path)
        img_original = cv2.cvtColor(img_original, cv2.COLOR_BGR2RGB)        
        
        with open(annotations_path) as f:
            data = json.load(f)
            bboxes_original = data['bboxes']
            keypoints_original = data['keypoints']
            

        img, bboxes, keypoints = img_original, bboxes_original, keypoints_original        
        
        # Convert everything into a torch tensor 
        bboxes = [min(bboxes[0][0], bboxes[0][2]), min(bboxes[0][1], bboxes[0][3]), max(bboxes[0][0], bboxes[0][2]), max(bboxes[0][1], bboxes[0][3])]
        bboxes = [bboxes]       
        bboxes = torch.as_tensor(bboxes, dtype=torch.float32)    
          
        target = {}
        target["boxes"] = bboxes
        target["labels"] = torch.as_tensor([1 for _ in bboxes], dtype=torch.int64) # all objects are glue tubes
        target["image_id"] = torch.tensor([idx])
        target["area"] = (bboxes[:, 3] - bboxes[:, 1]) * (bboxes[:, 2] - bboxes[:, 0])
        target["iscrowd"] = torch.zeros(len(bboxes), dtype=torch.int64)
        target["keypoints"] = torch.as_tensor(keypoints[0], dtype=torch.float32)        
        img = F.to_tensor(img)

        return img, target
    
    def __len__(self):
        return len(self.imgs_files)


def visualize(dataloader, idx):

    item = dataloader.dataset.__getitem__(idx)
    # img = (item[0].permute(1,2,0).numpy() * 255).astype(np.uint8)
    img = cv2.imread(os.path.join(KEYPOINTS_FOLDER_TRAIN, "images", dataloader.dataset.imgs_files[idx]))
    print(os.path.join(KEYPOINTS_FOLDER_TRAIN, "images", dataloader.dataset.imgs_files[idx]))

    kp = item[1]['keypoints'].numpy()
    kp = kp.astype(np.int32)
    vertices = kp[0, :, 0:2]

    connections = [[0, 1], [1, 2], [2, 3], [3, 0], [4, 5], [5, 6], [6, 7], [7, 4], [0, 4], [1, 5], [2, 6], [3, 7]]
    # connections = [[0, 1], [1, 2], [2, 3]]
    color = (0, 255, 0)
    thickness = 2

    for i in range(len(connections)):

        start_point = (int(vertices[connections[i][0], 0]), int(vertices[connections[i][0], 1]))
        end_point = (int(vertices[connections[i][1], 0]), int(vertices[connections[i][1], 1]))

        cv2.line(img, start_point, end_point, color, thickness)

    cv2.namedWindow("window", cv2.WINDOW_NORMAL)
    cv2.resizeWindow("window",1280, 720)
    cv2.imshow('window',img)
    cv2.waitKey(1000) 
    cv2.destroyAllWindows() 


def visualize_test(img, kp):

    kp = np.round(kp)
    kp = kp.astype(np.int32)

    vertices = kp

    connections = [[0, 1], [1, 2], [2, 3], [3, 0], [4, 5], [5, 6], [6, 7], [7, 4], [0, 4], [1, 5], [2, 6], [3, 7]]
    # connections = [[0, 1], [1, 2], [2, 3]]
    color = (0, 255, 0)
    thickness = 2

    vertices = vertices.reshape(8, 2)

    for i in range(len(connections)):

        start_point = (int(vertices[connections[i][0], 0]), int(vertices[connections[i][0], 1]))
        end_point = (int(vertices[connections[i][1], 0]), int(vertices[connections[i][1], 1]))

        cv2.line(img, start_point, end_point, color, thickness)

    cv2.namedWindow("window", cv2.WINDOW_NORMAL)
    cv2.resizeWindow("window",1280, 720)
    cv2.imshow('window',img)
    cv2.waitKey(5000) 
    cv2.destroyAllWindows() 


def get_model(num_keypoints, weights_path=None):
    
    anchor_generator = AnchorGenerator(sizes=(32, 64, 128, 256, 512), aspect_ratios=(0.25, 0.5, 0.75, 1.0, 2.0, 3.0, 4.0))
    model = torchvision.models.detection.keypointrcnn_resnet50_fpn(pretrained=False,
                                                                   pretrained_backbone=True,
                                                                   num_keypoints=num_keypoints,
                                                                   num_classes = 2, # Background is the first class, object is the second class
                                                                   rpn_anchor_generator=anchor_generator)

    if weights_path:
        state_dict = torch.load(weights_path)
        model.load_state_dict(state_dict)        

    return model        

def test_one_epoch(model, _data_loader_test, device, print_freq, scaler=None):
    # model.train()
    metric_logger_test = utils.MetricLogger(delimiter="  ")
    metric_logger_test.add_meter("lr", utils.SmoothedValue(window_size=1, fmt="{value:.6f}"))


    for images, targets in metric_logger_test.log_every(_data_loader_test, print_freq):
        images = list(image.to(device) for image in images)
        targets = [{k: v.to(device) for k, v in t.items()} for t in targets]
        with torch.cuda.amp.autocast(enabled=scaler is not None):
            loss_dict = model(images, targets)
            losses = sum(loss for loss in loss_dict.values())

        # reduce losses over all GPUs for logging purposes
        loss_dict_reduced = utils.reduce_dict(loss_dict)
        losses_reduced = sum(loss for loss in loss_dict_reduced.values())

        loss_value = losses_reduced.item()

        if not math.isfinite(loss_value):
            print(f"Loss is {loss_value}, stopping training")
            print(loss_dict_reduced)
            sys.exit(1)


        metric_logger_test.update(loss=losses_reduced, **loss_dict_reduced)
        metric_logger_test.update(lr=optimizer.param_groups[0]["lr"])

    return metric_logger_test

if __name__ == "__main__":


    # KEYPOINTS_FOLDER_TRAIN = '/home/bluesky/Downloads/glue_tubes_keypoints_dataset_134imgs/train'

    dataset = ClassDataset(KEYPOINTS_FOLDER_TRAIN)
    data_loader = DataLoader(dataset, batch_size=3, shuffle=True, collate_fn=collate_fn)

    data_loader.dataset.__getitem__(1)

    dataset_test = ClassDataset(KEYPOINTS_FOLDER_TEST)
    data_loader_test = DataLoader(dataset_test, batch_size=1, shuffle=False, collate_fn=collate_fn)


    # n = len(data_loader.dataset)

    for i in range(1):
            
        idx = random.randint(0, data_loader.__len__())

        visualize(data_loader, idx)

    device = torch.device('cuda') if torch.cuda.is_available() else torch.device('cpu')

    model = get_model(num_keypoints = 8)
    model.to(device)
    print("Device: ", device)


    if Model_Train:
        params = [p for p in model.parameters() if p.requires_grad]
        optimizer = torch.optim.SGD(params, lr=0.001, momentum=0.9, weight_decay=0.0005)
        lr_scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=5, gamma=0.3)
        num_epochs = 5

        loss_list = []

        csv_log_train = np.zeros([num_epochs, 8], dtype= np.float64)
        csv_log_test = np.zeros([num_epochs, 8], dtype= np.float64)

        for i in range(num_epochs):
            train_metrics = train_one_epoch(model, optimizer, data_loader, device, i, print_freq=20)
            test_metrics = test_one_epoch(model, data_loader_test, device, print_freq=20)

            print(train_metrics.meters['loss'].value, train_metrics.meters['loss_classifier'].value)
            lr_scheduler.step()

            test_eval = evaluate(model, data_loader_test, device)
            
            csv_log_train[i,0] = i
            for idx, item in enumerate(train_metrics.meters.values()):
                csv_log_train[i, idx+1] = item.value

            csv_log_test[i,0] = i
            for idx, item in enumerate(test_metrics.meters.values()):
                csv_log_test[i, idx+1] = item.value

        col_name = []

        col_name.append('Epoch')

        for item in train_metrics.meters.keys():
            col_name.append(item)

        df = pd.DataFrame(csv_log_train , columns = col_name).set_index('Epoch')
        df.to_csv(workspace_dir + '/repo/codes/logs/kp_vert_train_log.csv')


        df = pd.DataFrame(csv_log_test , columns = col_name).set_index('Epoch')
        df.to_csv(workspace_dir + '/repo/codes/logs/kp_vert_test_log.csv')

        torch.save(model, workspace_dir + '/repo/codes/bebop_rcnn.pt')
        
        os.getcwd()

        print("Training Finished!\n\n")

    model = torch.load(workspace_dir + '/repo/codes/bebop_rcnn.pt')

    img_list = os.listdir(os.path.join(KEYPOINTS_FOLDER_TEST, "images"))
    img_list.sort()

    test_idx = np.random.permutation(len(img_list))

    for j in range(5):

        n = test_idx[j]

        try:
            img_ = cv2.imread(os.path.join(KEYPOINTS_FOLDER_TEST, "images", img_list[n]))
            img = img = F.to_tensor(img_).to(device)

            model.eval()
            img.to(device)
            output = model([img])

            scores = output[0]['scores'].detach().cpu().numpy()
            np.where(scores > 0.6)[0].tolist()

            kp = output[0]['keypoints'][np.where(scores > 0.01)[0].tolist()].detach().cpu().numpy().astype(np.int32)
            kp = kp[0,:,0:2]

            print(kp)
            print(data_loader_test.dataset.__getitem__(n)[1]["keypoints"][:, :, :2])

            visualize_test(img_, kp)

        except Exception  as e:
            print(e)


