from importlib.resources import path
import os
import shutil
import rospkg


rospack = rospkg.RosPack()
workspace_dir = rospack.get_path('bebop_ros')	

dir_path = workspace_dir + "/repo/dataset"

try:
    shutil.rmtree(dir_path)
except:
    pass



os.mkdir(dir_path)
os.mkdir(os.path.join(dir_path, "count"))
os.mkdir(os.path.join(dir_path, "csv"))
os.mkdir(os.path.join(dir_path, "data"))
os.mkdir(os.path.join(dir_path, "data", "frames_bb"))
os.mkdir(os.path.join(dir_path, "data", "frames_raw"))
os.mkdir(os.path.join(dir_path, "data", "frames_mask"))
os.mkdir(os.path.join(dir_path, "data", "frames_bb_rectified"))
os.mkdir(os.path.join(dir_path, "data", "frames_keypoints"))
os.mkdir(os.path.join(dir_path, "data", "frames_selected"))


with open(workspace_dir + '/repo/dataset/count/frame_count.txt', 'w') as f:
    f.write('0')
