#! /usr/bin/env python

"""
Software License Agreement (BSD)

File: offset_removal.py
Author: Amir Hossein Ebrahimnezhad ebrahimnezhad@ualberta.ca
Maintainer: Martin Barczyk mbarczyk@ualberta.ca
Copyright: Copyright (c) 2023, Mechatronic Systems Lab (University of Alberta), All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that
the following conditions are met:

Redistributions of source code must retain the above copyright notice, this list of conditions and the
following disclaimer.
Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the
following disclaimer in the documentation and/or other materials provided with the distribution.
Neither the name of Mechatronic Systems Lab nor the names of its contributors may be used to endorse or promote
products derived from this software without specific prior written permission.
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WAR-
RANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, IN-
DIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
"""

import torch
from torchvision.transforms import functional as F
import torch.nn as nn

from detectron2.engine import DefaultPredictor
from detectron2.config import get_cfg
from detectron2.data import MetadataCatalog
from detectron2.utils.visualizer import ColorMode, Visualizer
from detectron2 import model_zoo

from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import numpy as np

import os
import cv2
import pandas as pd

import torch
import torch.nn as nn
import torch.nn.functional as F
from torchsummary import summary

import rospkg
import requests
import zipfile


resize_ratio = 1 
dataSave = False

class Detector:
    
    def __init__(self, ros_ws):
        self.cfg = get_cfg()
        self.cfg.merge_from_file(model_zoo.get_config_file("COCO-InstanceSegmentation/mask_rcnn_R_50_FPN_3x.yaml"))
        self.cfg.DATASETS.TRAIN = ("Drone_train",)
        self.cfg.DATASETS.TEST = ()
        self.cfg.DATALOADER.NUM_WORKERS = 2
        self.cfg.MODEL.WEIGHTS = os.path.join(self.cfg.OUTPUT_DIR, ros_ws + "/repo/codes/model_final.pth")
        self.cfg.MODEL.ROI_HEADS.NUM_CLASSES = 1

        self.cfg.MODEL.ROI_HEADS.SCORE_THRESH_TEST = 0.5   # set the testing threshold for this model
        self.cfg.DATASETS.TEST = ("drone", )
        self.predictor = DefaultPredictor(self.cfg)
        
        for d in ["train", "test"]:

            MetadataCatalog.get("Drone_" + d).set(thing_classes=['Drone'])

        self.Drone_metadata = MetadataCatalog.get("Drone_train")
        self.D_data = MetadataCatalog.get("Bebop").set(thing_colors=[(255, 255, 255)])


        self.workspace_dir = ros_ws
        print(os.path.join(self.workspace_dir, "repo/dataset/data/frames_raw"))

        self.img_path = os.path.join(self.workspace_dir, "repo/dataset/data/frames_raw")
        self.csv_path = os.path.join(self.workspace_dir, "repo/dataset/csv/img_rel_pose_offset.csv")
        self.frame_mask_path = os.path.join(self.workspace_dir, "repo/dataset/data/frames_bb_rectified")
        self.frame_offset_path = os.path.join(self.workspace_dir, "repo/dataset/data/frames_offset")
        self.frame_selected_path = os.path.join(self.workspace_dir, "repo/dataset/data/frames_selected")
        
        self.img =  np.zeros((480,856,3), np.uint8)

        print(self.img_path)
        self.list_img = os.listdir(self.img_path)
        self.list_img.sort()

        self.pose_data = pd.read_csv(self.csv_path)
        self.pose_np = self.pose_data.to_numpy()

        self.rows, self.cols = self.pose_np.shape

        # temp_arr = np.zeros([self.rows, 3])
        # self.pred_data = np.append(self.pose_np[:, 0:3], temp_arr, axis=1)

        # self.pred_data = np.copy(self.pose_np)

        temp_arr = np.zeros([self.rows, 4])
        self.pred_data = np.append(self.pose_np, temp_arr, axis=1)

        self.pred_data_mod = []

        self.connections = [[0, 1], [1, 2], [2, 3], [3, 0], [4, 5], [5, 6], [6, 7], [7, 4], [0, 4], [1, 5], [2, 6], [3, 7]]
    
        self.color_green = (0, 255, 0)
        self.color_red = (0, 0, 255)
        self.thickness = 2

        self.col_names = []
        
        for col in self.pose_data.columns:
            self.col_names.append(col)

        self.col_names.append('b0[u]')
        self.col_names.append('b0[v]')
        self.col_names.append('b1[u]')
        self.col_names.append('b1[v]')

        self.bridge = CvBridge()
        self.dim = (int(1280/resize_ratio), int(720/resize_ratio))

        self.img_count = 0


    def vert_com(self, idx):
        com = self.pose_np[idx, 5:21].reshape(8,2)
        return np.mean(com, axis=0)

    def offset_removal(self, bb_com, idx):
        
        offset = bb_com - self.vert_com(idx)
        offset_array = np.zeros([8,2])

        offset_array[:,0] = offset[0]
        offset_array[:,1] = offset[1]

        refined_vert = self.pose_np[idx, 5:21].reshape(8,2) + offset_array

        return refined_vert.reshape(-1)


    def replace_vert(self, refined_Vert, idx):
        self.pred_data[idx, 5:21] = refined_Vert.astype(np.uint32)
        new_img_idx = "img" + "{:04d}".format(detector.img_count) + ".jpg"

        self.replace_img_idx(idx, new_img_idx)
        self.pred_data_mod.append(self.pred_data[idx])

    def replace_img_idx(self, idx, new_img_idx):
        self.pred_data[idx, 0] = new_img_idx


    def visualize(self, image, vertices, idx):

        vertices = vertices.reshape(8, 2)
        vertices_offset = self.pose_np[idx, 5:21].reshape(8,2)

        for i in range(len(self.connections)):

            start_point = (int(vertices[self.connections[i][0], 0]), int(vertices[self.connections[i][0], 1]))
            end_point = (int(vertices[self.connections[i][1], 0]), int(vertices[self.connections[i][1], 1]))

            cv2.line(image, start_point, end_point, self.color_green, self.thickness)

        green_frame = image.copy()

        for i in range(len(self.connections)):

            start_point = (int(vertices_offset[self.connections[i][0], 0]), int(vertices_offset[self.connections[i][0], 1]))
            end_point = (int(vertices_offset[self.connections[i][1], 0]), int(vertices_offset[self.connections[i][1], 1]))

            cv2.line(image, start_point, end_point, self.color_red, self.thickness)

        cv2.imshow("Image window", image)
        cv2.waitKey(3)   

        return green_frame, image


def download_file(url, file_path, dir):
    response = requests.get(url)
    if response.status_code == 200:
        with open(file_path, 'wb') as file:
            file.write(response.content)

        with zipfile.ZipFile(file_path, 'r') as zip_ref:
            zip_ref.extractall(dir + "/repo/codes")
        print(f"File downloaded successfully: {file_path}")
    else:
        print("Error downloading file.")
        
def check_and_download_file(url, file_path, zip_file_path, dir):
    if os.path.exists(file_path):
        print("File already exists.")
    else:
        download_file(url, zip_file_path, dir)


if __name__ == "__main__":
        
    TORCH_VERSION = ".".join(torch.__version__.split(".")[:2])
    CUDA_VERSION = torch.__version__.split("+")[-1]
    print("torch: ", TORCH_VERSION, "; cuda: ", CUDA_VERSION)


    rospack = rospkg.RosPack()
    workspace_ros = rospack.get_path('bebop_ros')	

    mask_rcnn_model_url = "https://github.com/roboticswithamir/docs/raw/main/bebop_ros/Models/model_final.zip"
    local_file_path = workspace_ros + "/repo/codes/model_final.pth"
    local_zip_file_path = workspace_ros + "/repo/codes/model_final.zip"

    # Check and download the file if it doesn't exist
    check_and_download_file(mask_rcnn_model_url, local_file_path, local_zip_file_path, workspace_ros)


    detector = Detector(workspace_ros)

    bb_points = np.zeros([1, 4])
    print("\n\n")

    for i in range (150, 250):

    # for i in range (len(detector.list_img)):

        cv_image = cv2.imread(os.path.join(detector.img_path, detector.list_img[i]))

        img = cv2.resize(cv_image, detector.dim)

        outputs = detector.predictor(cv_image)

        v = Visualizer(cv_image[:, :, ::-1], metadata=detector.D_data , scale=1.0, instance_mode=ColorMode.SEGMENTATION)
        v = v.draw_instance_predictions(outputs["instances"].to("cpu"))
        img_annot = cv2.cvtColor(v.get_image()[:, :, ::-1], cv2.COLOR_BGR2RGB)


        mask = outputs["instances"].to("cpu")  
        pred_boxes = mask.pred_boxes
        scores = mask.scores.numpy()

        try:
            is_pred_boxes = pred_boxes.nonempty()[0]
        except:
            is_pred_boxes = False

        if is_pred_boxes and (scores[0] > 0.92):

            print(scores, "\n")
            bb_com = np.array(pred_boxes.get_centers())[0]

            bb_points = pred_boxes.tensor.cpu()
            bb_points = bb_points.numpy()

            detector.pred_data[i, -4:] = bb_points[0].astype(int)

            refined_vect = detector.offset_removal(bb_com, i)

            detector.replace_vert(refined_vect, i)

            annotated_frame, img_offset = detector.visualize(cv_image, refined_vect, i)

            if dataSave:
                # cv2.imwrite(os.path.join(detector.frame_mask_path, "bb_" + detector.list_img[i]) ,annotated_frame)
                # cv2.imwrite(os.path.join(detector.frame_offset_path, "offset_" + detector.list_img[i]) ,img_offset)
                cv2.imwrite(os.path.join(detector.frame_selected_path, "img" + "{:04d}".format(detector.img_count)+".jpg") , img)

            detector.img_count +=1
            

        else:

            print("Object not detected!\n")
            detector.pred_data[i, -4:] = bb_points[0].astype(int)



        print("\033[A\033[A")
        print("Completion: ",int(i/len(detector.list_img)*100), "%")

    if dataSave:
        # df = pd.DataFrame(np.array(detector.pred_data) , columns = detector.col_names).set_index('Frame ID')
        df = pd.DataFrame(np.array(detector.pred_data_mod) , columns = detector.col_names).set_index('Frame ID')
        df.to_csv(detector.workspace_dir + '/repo/dataset/csv/img_rel_pose.csv')

    print("Processing Finished!")

    cv2.destroyAllWindows() 

