/**
Software License Agreement (BSD)

\file     bp_brd.cpp
\author   Amir Hossein Ebrahimnezhad <ebrahimnezhad@ualberta.ca>
\maintainer Martin Barczyk <mbarczyk@ualberta.ca>
\copyright Copyright (c) 2023, Mechatronic Systems Lab (University of Alberta), All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that
the following conditions are met:
 * Redistributions of source code must retain the above copyright notice, this list of conditions and the
   following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the
   following disclaimer in the documentation and/or other materials provided with the distribution.
 * Neither the name of Mechatronic Systems Lab nor the names of its contributors may be used to endorse or promote
   products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WAR-
RANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, IN-
DIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/


#include <ros/ros.h>
#include <tf/transform_broadcaster.h>
#include <turtlesim/Pose.h>

std::string turtle_name;



int main(int argc, char** argv){
    ros::init(argc, argv, "vicon_broadcaster_node");


    static tf::TransformBroadcaster br;
    tf::Transform transform_prs, transform_trg;
    
    transform_prs.setOrigin( tf::Vector3(-1.0, 0.0, 1.0) );
    transform_trg.setOrigin( tf::Vector3(2.0, 1.0, 2.0) );

    tf::Quaternion q;
    q.setRPY(0, 0, 0);
    transform_prs.setRotation(q);
    transform_trg.setRotation(q);

    ros::Rate rate(25);

    ros::NodeHandle node;
    while(ros::ok())
    {

        br.sendTransform(tf::StampedTransform(transform_prs, ros::Time::now(), "map", "vicon/bebop/bebop"));
        br.sendTransform(tf::StampedTransform(transform_trg, ros::Time::now(), "map", "vicon/target/target"));


        tf::Vector3 position = transform_prs.getOrigin();
        tf::Quaternion orientation = transform_prs.getRotation();

        ROS_INFO("Position: x=%.2f, y=%.2f, z=%.2f", position.x(), position.y(), position.z());
        ROS_INFO("Orientation: x=%.2f, y=%.2f, z=%.2f, w=%.2f", orientation.x(), orientation.y(), orientation.z(), orientation.w());  

        rate.sleep();
        ros::spinOnce(); 
    }

    return 0;
};