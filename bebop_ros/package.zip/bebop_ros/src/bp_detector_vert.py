#!/usr/bin/env python

"""
Software License Agreement (BSD)

File: bp_detector_vert.py
Author: Amir Hossein Ebrahimnezhad ebrahimnezhad@ualberta.ca
Maintainer: Martin Barczyk mbarczyk@ualberta.ca
Copyright: Copyright (c) 2023, Mechatronic Systems Lab (University of Alberta), All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that
the following conditions are met:

Redistributions of source code must retain the above copyright notice, this list of conditions and the
following disclaimer.
Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the
following disclaimer in the documentation and/or other materials provided with the distribution.
Neither the name of Mechatronic Systems Lab nor the names of its contributors may be used to endorse or promote
products derived from this software without specific prior written permission.
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WAR-
RANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, IN-
DIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
"""


import torch
from torchvision.transforms import functional as F

import rospy
import rospkg

from sensor_msgs.msg import Image
from cv_bridge import CvBridge

import numpy as np
import cv2
import time

from bebop_ros.msg import kpData

Resized_frame = False

kp_num = 8*2

global vert_enh


if Resized_frame:
    resize_ratio = 4

else:
    resize_ratio = 1

class Detector:
    
    def __init__(self, ros_ws):


        self.device = torch.device('cuda') if torch.cuda.is_available() else torch.device('cpu')

        self.model = torch.load(ros_ws + '/repo/codes/bebop_rcnn.pt')

        self.model.to(self.device)

        self.img =  np.zeros((720,1280,3), np.uint8)

        self.kp_pub =  rospy.Publisher('/bebop/keypoints/raw', kpData)
        self.image_pub = rospy.Publisher("/bebop/frames_bb",Image, queue_size=10)
        self.image_sub = rospy.Subscriber("/bebop/image_raw",Image, self.callback_frame)
        

        self.bridge = CvBridge()
        self.dim = (int(1280/resize_ratio), int(720/resize_ratio))

        self.prev_frame_time = 0
        self.new_frame_time = 0

        self.connections = [[0, 1], [1, 2], [2, 3], [3, 0], [4, 5], [5, 6], [6, 7], [7, 4], [0, 4], [1, 5], [2, 6], [3, 7]]
        self.color = (0, 255, 0)
        self.thickness = 2

        self.kp_array = kpData()
        self.bridge = CvBridge()


        

    def visualize_test(self, cv_image, kp):

        kp = np.round(kp)
        kp = kp.astype(np.int32)

        vertices = kp
        vertices = vertices.reshape(8, 2)

        for i in range(len(self.connections)):

            start_point = (int(vertices[self.connections[i][0], 0]), int(vertices[self.connections[i][0], 1]))
            end_point = (int(vertices[self.connections[i][1], 0]), int(vertices[self.connections[i][1], 1]))

            cv2.line(cv_image, start_point, end_point, self.color, self.thickness)


        self.image_pub.publish(self.bridge.cv2_to_imgmsg(cv_image, "bgr8"))

        cv2.namedWindow("window", cv2.WINDOW_NORMAL)
        cv2.resizeWindow("window",1280, 720)
        cv2.imshow('window',cv_image)
        cv2.waitKey(3) 

    def kp_enhancement(self, kp):

        vertices = kp
        vertices = vertices.reshape(8, 2)

        u0 = vertices[0, 0]
        v0 = vertices[0, 1]

        u1 = vertices[1, 0]
        v3 = vertices[3, 1]

        u4 = vertices[4, 0]
        v4 = vertices[4, 1]

        u5 = vertices[5, 0]

        v7 = vertices[7, 1]

        h1 = v3-v0
        w1 = u1-u0

        h2 = v7-v4
        w2 = u5-u4


        vertices[1, :] = [u0+w1, v0]
        vertices[2, :] = [u0+w1, v0+h1]
        vertices[3, :] = [u0, v0+h1]

        vertices[5, :] = [u4+w2, v4]
        vertices[6, :] = [u4+w2, v4+h2]
        vertices[7, :] = [u4, v4+h2]

        return vertices.reshape(-1)


    def callback_frame(self, image):

        self.frame = image


if __name__ == "__main__":


    rospy.init_node('bebop_vertices_node')
    vert_enh = rospy.get_param("~vertice_enhancement")

    rospy.loginfo('Detection Initiated!')  

    rate = rospy.Rate(10)

    rospack = rospkg.RosPack()
    workspace_ros = rospack.get_path('bebop_ros')

    detector = Detector(workspace_ros)
    


    while not rospy.is_shutdown():

        try:
            
            cv_image = detector.bridge.imgmsg_to_cv2(detector.frame, "bgr8")
            img = F.to_tensor(cv_image).to(detector.device)

            
            detector.model.eval()
            output = detector.model([img])

            scores = output[0]['scores'].detach().cpu().numpy()
            np.where(scores > 0.6)[0].tolist()

            kp = output[0]['keypoints'][np.where(scores > 0.01)[0].tolist()].detach().cpu().numpy().astype(np.int32)
            kp = kp[0,:,0:2]

            if(vert_enh == "on"):
                kp = detector.kp_enhancement(kp)

            detector.visualize_test(cv_image, kp)

            detector.kp_array.vert_kp = np.copy(kp.astype(np.int32).reshape(-1))
            detector.kp_pub.publish(detector.kp_array)

    
        except Exception as e:
            print(e)

        rate.sleep()


    print("Shutting down")

    cv2.destroyAllWindows()
    