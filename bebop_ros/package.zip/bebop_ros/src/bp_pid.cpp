/**
Software License Agreement (BSD)

\file      bp_pid.cpp
\author   Amir Hossein Ebrahimnezhad <ebrahimnezhad@ualberta.ca>
\maintainer Martin Barczyk <mbarczyk@ualberta.ca>
\copyright Copyright (c) 2023, Mechatronic Systems Lab (University of Alberta), All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that
the following conditions are met:
 * Redistributions of source code must retain the above copyright notice, this list of conditions and the
   following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the
   following disclaimer in the documentation and/or other materials provided with the distribution.
 * Neither the name of Mechatronic Systems Lab nor the names of its contributors may be used to endorse or promote
   products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WAR-
RANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, IN-
DIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

//ROS Headers
#include <ros/ros.h>
#include <ros/package.h>
#include <geometry_msgs/Twist.h>
#include <geometry_msgs/TransformStamped.h>
#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>
#include <sensor_msgs/image_encodings.h>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>

#include<tf/transform_listener.h>
#include<tf/tf.h>
#include<tf/transform_datatypes.h>
#include<tf/transform_broadcaster.h>
#include <tf/transform_datatypes.h>
#include <eigen3/Eigen/Dense>                
#include <eigen3/unsupported/Eigen/MatrixFunctions>

//Custom Libraries
#include <csv_mng.h>
#include <pid_ctrl.h>
#include <gui_bar.h>

// Header Files Specific to the project
#include"../include/twistops.hpp" 

//C++ I/O
#include <iostream>
#include <stdio.h>
#include <string>
#include <sstream>
#include <fstream> 
#include <stdlib.h>
#include <unistd.h>
#include <filesystem>

//Standard headers
#include <time.h>
#include <math.h>



// Classes
class PID_Class 
{

    // NodeHandle
    ros::NodeHandle nh_;
    ros::NodeHandle private_nh;

    // Subscribers
    ros::Subscriber sp_sub;

    // Publishers
    ros::Publisher rel_pub, fb_pub, cmd_pub;

public:

    // Publish Variables
    double secs_init = ros::Time::now().toSec();

    // Frequency and Time
    double f = 25;
    double t_ros = 0.;
    double dt_ = 1.0/f;

    // Variables 
    double delay_time = 2.0;
    double pulse_time = 13.0;
    double pulse_period = 30.0;
    double t_sim;
    int speed_sat = 2.0;
    int pid_activation = 0;

    geometry_msgs::Pose fb_pose;
    // PID Parameters
    PIDController pid_x, pid_y, pid_z, pid_yaw;

    double k_x[3] = {0., 0., 0.};
    double k_y[3] = {0., 0., 0.};
    double k_z[3] = {0., 0., 0.};
    double k_yaw[3] = {0., 0., 0.};

    double k_anti_wp = 0.5;
    double k_div[3] = {1000, 10000, 1000};

	// Messages 
	Twist bp_ctrl; //Twist 
    Twist null_ctrl; //Twist  

	// Intialize Variables 
	int i; 

	// /tf Variables 
    tf::TransformListener listener;
	tf::StampedTransform transform_prs, transform_trg;   

    tf::Vector3	p_fb, p_sp;	// Feedback and Setpoint Position Vectors
    tf::Matrix3x3 R_fb, R_sp;
    double roll_fb, pitch_fb, yaw_fb = 0.0;
    double roll_sp, pitch_sp, yaw_sp = 0.0;

    // Strings
    std::string temp_param;
    std::string axis;
    std::string pulse_mode; // cmd_vel or cmd_pos
    std::string savePID; // cmd_vel or cmd_pos

    std::string filename;
    std::vector<std::string> headers = { "Time (s)", "PID_x", "PID_y", "PID_z", "PID_yaw", "x_bebop [m]", "y_bebop [m]", "z_bebop [m] ", "roll_bebop [rad]", "pitch_bebop [rad]", "yaw_bebop [rad]", "sp_x [m]", "sp_y [m]", "sp_z [m]", "sp_yaw [rad]"};
    std::string repo_path;
    std::string workspacePath = ros::package::getPath("bebop_ros");
    char currentDir[FILENAME_MAX];

    // Objects
    CSVManager csvManager_;


    std::vector<std::string> barNames = {"x_Kp", "x_Ki", "x_Kd", "y_Kp", "y_Ki", "y_Kd", "z_Kp", "z_Ki", "z_Kd", "yaw_Kp", "yaw_Ki", "yaw_Kd", "PID Activation"};
    std::vector<int> scales = {10000, 100000, 10000, 10000, 100000, 10000, 10000, 100000, 10000, 10000, 100000, 10000, 1};
    std::vector<int> values = {2500, 62, 2150, 2050, 100, 2200, 3500, 30, 1100, 708, 0, 0, 0};
    std::string windowName = "PID Parameters";
    int numBars = barNames.size();

    // Create an instance of the GuiBar class
    GuiBar guiBar;

    // Constructor
    PID_Class()
        : private_nh("~"),
          pid_x(k_x, dt_, k_anti_wp),
          pid_y(k_y, dt_, k_anti_wp),
          pid_z(k_z, dt_, k_anti_wp),
          pid_yaw(k_yaw, dt_, k_anti_wp),
          guiBar(barNames, scales, numBars, windowName, values)
    {

        ROS_INFO("Starting Node...\n");
        ROS_INFO("OpenCV version: %s\n",CV_VERSION);

        // Receiving Parameters
        private_nh.getParam("pulse_mode", pulse_mode); //cmd_vel or cmd_pos
        private_nh.getParam("t_sim", t_sim);
        private_nh.getParam("axis", axis);
        private_nh.getParam("savePID", savePID);

        // Publishers
        rel_pub = nh_.advertise<geometry_msgs::Pose>("/bebop/relpos/vicon",1000);
        fb_pub = nh_.advertise<geometry_msgs::Pose>("/bebop/fbData",1000);
        cmd_pub = nh_.advertise<geometry_msgs::Twist>("/bebop/cmd_vel",1000);

        // Subscribers
        sp_sub = nh_.subscribe("/bebop/spData", 1, &PID_Class::setpointCallback, this);

        if (!workspacePath.empty()) {
            std::cout << "Catkin workspace path: " << workspacePath << std::endl;
        } else {
            std::cout << "Failed to retrieve Catkin workspace path." << std::endl;
        }

        repo_path = workspacePath + "/repo/pid/csv/";
        filename =  repo_path + pulse_mode + "_" + axis + ".csv";
        csvManager_.addPath(workspacePath + "/repo/pid/csv/" + pulse_mode + "_" + axis + ".csv", headers);
        
        // Setting setpoint and feedback vectors to zero
        p_fb.setZero();
        p_sp.setZero();
    }

    // Deconstructor
    ~PID_Class()
    {
        // cv::destroyWindow(OPENCV_WINDOW);
        csvManager_.save();

    }
 
    void updateFeedbackPose(tf::StampedTransform uav_transform)
    {
        p_fb = uav_transform.getOrigin();
        R_fb.setRotation(uav_transform.getRotation());
        R_fb.getRPY(roll_fb, pitch_fb, yaw_fb);

        fb_pose.position.x = p_fb[0];
        fb_pose.position.y = p_fb[1];
        fb_pose.position.z = p_fb[2];

        fb_pose.orientation.z = yaw_fb;

        fb_pub.publish(fb_pose);

    }

    void setpointCallback(geometry_msgs::Pose sp_topic) 
    {
        // bp_sp.position = sp_topic.position;
        // bp_sp.orientation = sp_topic.orientation;
        // tf::Quaternion quat(sp_topic.orientation.x, sp_topic.orientation.y, sp_topic.orientation.z, sp_topic.orientation.w);
        // tf::Matrix3x3 mat(quat);
        // mat.getRPY(roll_sp, pitch_sp, yaw_sp);

        p_sp = {sp_topic.position.x, sp_topic.position.y, sp_topic.position.z};
        yaw_sp = sp_topic.orientation.z;

        ROS_INFO("The input node is heard");
    }

    void updateTime()
    {
        t_ros += dt_;
    }

    void calculateCMD()
    {
        bp_ctrl.linear.x = pid_x.compute(p_sp[0] - p_fb[0]);
        bp_ctrl.linear.y = pid_y.compute(p_sp[1] - p_fb[1]);
        bp_ctrl.linear.z = pid_z.compute(p_sp[2] - p_fb[2]);
        bp_ctrl.angular.z = pid_yaw.compute(adjustYaw(yaw_sp, yaw_fb));
    }

    void updatePIDParams()
    {
		for (i = 0; i < 3; i++)
		{ 
			k_x[i] = ((double) guiBar.values_[i])/k_div[i];
			k_y[i] = ((double) guiBar.values_[i+3])/k_div[i];
			k_z[i] = ((double) guiBar.values_[i+6])/k_div[i];
            k_yaw[i] = ((double) guiBar.values_[i+9])/k_div[i];
		}

        pid_x.setGains(k_x);
        pid_y.setGains(k_y);
        pid_z.setGains(k_z);
        pid_yaw.setGains(k_yaw);
    }

    void publishCMD(Twist vel_ctrl)
    {
        cmd_pub.publish(vel_ctrl);
    }

    void writeCSV()
    {
        double data_[] = {t_ros, bp_ctrl.linear.x, bp_ctrl.linear.y, bp_ctrl.linear.z, bp_ctrl.angular.z, p_fb[0], p_fb[1], p_fb[2], roll_fb, pitch_fb, yaw_fb, p_sp[0], p_sp[1], p_sp[2], yaw_sp};
        csvManager_.addRow(transformToVector(data_, 15));
    }

    double adjustYaw(double setpoint, double yaw)
    {
        double eyaw = setpoint - yaw;

        if (eyaw < (-1)*M_PI)
        {
            eyaw = eyaw + 2*M_PI;
        }
        else if (eyaw > M_PI)
        {
            eyaw = eyaw - 2*M_PI;
        } 
        return eyaw;

    }

    std::vector<std::string> transformToVector(const double* arr, int size)
    {
        std::vector<std::string> result;
        result.reserve(size);
        for (int i = 0; i < size; ++i)
        {
        result.emplace_back(std::to_string(arr[i]));
        }
        return result;
    }

    void checkActivation(int newState)
    {

        if (pid_activation == 1 && newState == 0)
        {
            publishCMD(null_ctrl);
        }

        // Update the variable state
        pid_activation = newState;    
    }    
    
};



int main(int argc, char** argv)
{
    //Initiations
    ros::init(argc, argv, "bebop_pid_node");
    ROS_INFO("Node Initiated!\n");

    // Object Declaration
    PID_Class pid_controller;

    // ROS Rate
    ros::Rate rate(pid_controller.f);
    double t_node_ = ros::Time::now().toSec();

    // TF
    tf::TransformListener listener;
    tf::StampedTransform uav_prs_transform;

    while (ros::ok())
	{
		//Update Trackbar 
		cv::waitKey(10);

        try
        {
            listener.lookupTransform("/map","/vicon/bebop/bebop",ros::Time(0),uav_prs_transform);
        }
        catch (tf::TransformException ex) 
        {
            ROS_ERROR("%s",ex.what());
        }

        pid_controller.updateFeedbackPose(uav_prs_transform);
        pid_controller.updatePIDParams();
        pid_controller.calculateCMD();
        if(pid_controller.guiBar.values_[12]) pid_controller.publishCMD(pid_controller.bp_ctrl);
        pid_controller.checkActivation(pid_controller.guiBar.values_[12]);
        pid_controller.writeCSV();
        
        pid_controller.updateTime();

        ros::spinOnce(); 
        rate.sleep();
        
        
    }

    std::cout << "Catkin workspace path: " << pid_controller.workspacePath + "/repo/pid/csv/" + pid_controller.pulse_mode + "_" + pid_controller.axis + ".csv" << std::endl;
    
    return 0;
}