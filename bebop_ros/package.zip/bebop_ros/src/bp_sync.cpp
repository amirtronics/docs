/**
Software License Agreement (BSD)

\file     bp_sync.cpp
\author   Amir Hossein Ebrahimnezhad <ebrahimnezhad@ualberta.ca>
\maintainer Martin Barczyk <mbarczyk@ualberta.ca>
\copyright Copyright (c) 2023, Mechatronic Systems Lab (University of Alberta), All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that
the following conditions are met:
 * Redistributions of source code must retain the above copyright notice, this list of conditions and the
   following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the
   following disclaimer in the documentation and/or other materials provided with the distribution.
 * Neither the name of Mechatronic Systems Lab nor the names of its contributors may be used to endorse or promote
   products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WAR-
RANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, IN-
DIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include <ros/ros.h>
#include <ros/package.h>
#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>
#include <sensor_msgs/image_encodings.h>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>

#include<tf/transform_listener.h>
#include<tf/tf.h>
#include<tf/transform_datatypes.h>
#include<tf/transform_broadcaster.h>

//Custom Message Declaration 
#include <bebop_ros/spData.h>
#include <bebop_ros/rpData.h>
#include <bebop_ros/vertices.h>

//C++ I/O
#include <iostream>
#include <stdio.h>
#include <string>
#include <sstream>
#include <fstream> 
#include <sys/stat.h>

//Standard headers
#include <time.h>
#include <math.h>

#include <unistd.h>


static const std::string OPENCV_WINDOW = "Image window";

bebop_ros::rpData cb_relpose;
tf::Vector3 p_bebop_vertices[8];
tf::Vector3 vertex_pixel[8];

tf::Matrix3x3 M_int;

int connections[12][2] = {{0, 1}, {1, 2}, {2, 3}, {3, 0},
                          {4, 5}, {5, 6}, {6, 7}, {7, 4},
                          {0, 4}, {1, 5}, {2, 6}, {3, 7}};

                  
int img_count;
double t_start;


class ImageConverter
{
    ros::NodeHandle nh_;
    ros::NodeHandle private_nh;
    image_transport::ImageTransport it_;
    image_transport::Subscriber image_sub_;
    // image_transport::Publisher image_pub_;
    ros::Subscriber vertex_sub_;
    ros::Subscriber pose_sub_;


public:


    double secs_init = ros::Time::now().toSec();
    double secs_currrent;

    double pose_anafi[6];
    double pose_bebop[6];

    std::string workspacePath = ros::package::getPath("bebop_ros");

    std::string dataPath = workspacePath + "/repo/dataset/data/";

    std::string imgPath = dataPath + "frames_raw/";
    std::string img_bb_path = dataPath + "frames_bb/";
    std::string csvPath = workspacePath + "/repo/dataset/csv/";
    std::string frame_path;
    std::string frame_bb_path;
    char s[25];
    std::ofstream myfile;

    std::ofstream outputFile;
    std::string filename = csvPath + "img_rel_pose_offset.csv";


    ImageConverter()
        : private_nh("~"),
          it_(nh_)
    {


        private_nh.getParam("t_start_vis", t_start);

        sleep((int) (t_start));


        // std::cout << "t_start:     " << t_start << "\n";
        // std::cout << "ros time: " << secs_init << "\n";

        // Subscribe to input video feed and publish output video feed

        image_sub_ = it_.subscribe("/bebop/image_raw", 1, &ImageConverter::imageCb, this);
        vertex_sub_  = nh_.subscribe("/bebop/vertices", 1000, &ImageConverter::vertexCb, this);
        pose_sub_  = nh_.subscribe("/bebop/rpData", 1000, &ImageConverter::poseCb, this);
        // image_pub_ = it_.advertise("/image_converter/output_video", 1);
        
        std::cout << filename << "\n";
        outputFile.open(filename, std::ios::app);

        if (img_count == 0)
            outputFile << "Frame ID" << "," 

                       << "Time (sec)" << "," 

                       << "x_rel [m]" << ","
                       << "y_rel [m]" << ","
                       << "z_rel [m]" << ","

                       << "v0 [u]" << ","
                       << "v0 [v]" << ","

                       << "v1 [u]" << ","
                       << "v1 [v]" << ","

                       << "v2 [u]" << ","
                       << "v2 [v]" << ","

                       << "v3 [u]" << ","
                       << "v3 [v]" << ","

                       << "v4 [u]" << ","
                       << "v4 [v]" << ","

                       << "v5 [u]" << ","
                       << "v5 [v]" << ","

                       << "v6 [u]" << ","
                       << "v6 [v]" << ","

                       << "v7 [u]" << ","
                       << "v7 [v]" << ","

                       << "x_bebop [m]" << ","
                       << "y_bebop [m]" << ","
                       << "z_bebop [m]" << ","  

                       << "roll_bebop [rad]" << ","
                       << "pitch_bebop [rad]" << ","
                       << "yaw_bebop [rad]" << ","

                       << "x_target [m]" << ","
                       << "y_target [m]" << ","
                       << "z_target [m]" << ","

                       << "roll_target [rad]" << ","
                       << "pitch_target [rad]" << ","
                       << "yaw_target [rad]" 

                       << std::endl;

        cv::namedWindow(OPENCV_WINDOW);

        // M_int.setValue( 920.558594, 0.0, 670.928177,
        //         0.0, 925.233887, 385.146823,
        //         0.0, 0.0, 1.0);

        // M_int.setValue( 941.351807, 0.0, 638.966758,
        //         0.0, 948.554382, 375.830477,
        //         0.0, 0.0, 1.0);

        // M_int.setValue( 396.17782, 0.0, 322.453185,
        //         0.0, 399.798333, 174.243174,
        //         0.0, 0.0, 1.0);


        M_int.setValue( 738.195207, 0.0, 692.062813,
                0.0, 725.632258, 382.888215,
                0.0, 0.0, 1.0);
                

        for (int i = 0; i < 8; i++)
        { 
            vertex_pixel[i].setValue(0.0, 0.0, 0.0);
        }
    }

    ~ImageConverter()
    {
        
        cv::destroyWindow(OPENCV_WINDOW);

        myfile.open(workspacePath + "/repo/dataset/count/frame_count.txt");
        myfile << std::to_string(img_count);
        myfile.close();

        if (img_count == 0)
        {
            std::ofstream ofs;
            outputFile.open(filename, std::ofstream::out | std::ofstream::trunc);
            outputFile.close();
        }
    }

    bool directoryExists(const std::string& path) 
    {
        struct stat info;
        if (stat(path.c_str(), &info) != 0)
            return false;
        return (info.st_mode & S_IFDIR) != 0;
    }

    void poseCb(const bebop_ros::rpData& msg)
    {

        cb_relpose.xrel = msg.xrel;
        cb_relpose.yrel = msg.yrel;
        cb_relpose.zrel = msg.zrel;

        cb_relpose.pose_target = msg.pose_target;
        cb_relpose.pose_bebop = msg.pose_bebop;


    }

    void vertexCb(const bebop_ros::vertices& msg)
    {

        p_bebop_vertices[0] = {msg.v0[0], msg.v0[1], msg.v0[2]};
        p_bebop_vertices[1] = {msg.v1[0], msg.v1[1], msg.v1[2]};
        p_bebop_vertices[2] = {msg.v2[0], msg.v2[1], msg.v2[2]};
        p_bebop_vertices[3] = {msg.v3[0], msg.v3[1], msg.v3[2]};

        p_bebop_vertices[4] = {msg.v4[0], msg.v4[1], msg.v4[2]};
        p_bebop_vertices[5] = {msg.v5[0], msg.v5[1], msg.v5[2]};
        p_bebop_vertices[6] = {msg.v6[0], msg.v6[1], msg.v6[2]};
        p_bebop_vertices[7] = {msg.v7[0], msg.v7[1], msg.v7[2]};


    }
    
    void imageCb(const sensor_msgs::ImageConstPtr& msg)
    {

        cv_bridge::CvImagePtr cv_ptr;
        cv_bridge::CvImagePtr cv_ptr_raw;

        secs_currrent = ros::Time::now().toSec() - secs_init;
        // std::cout << "ros time: \n" << secs_currrent << "\n";


        try
        {
            cv_ptr = cv_bridge::toCvCopy(msg, sensor_msgs::image_encodings::BGR8);
            cv_ptr_raw = cv_bridge::toCvCopy(msg, sensor_msgs::image_encodings::BGR8);
        }
        
        catch (cv_bridge::Exception& e)
        {
            ROS_ERROR("cv_bridge exception: %s", e.what());
            return;
        }

        if (cv_ptr)
        {
        
            if(cv_ptr->image.rows != 720 || cv_ptr->image.cols != 1280)
            {

                std::cout << cv_ptr->image.rows << " " << cv_ptr->image.cols << "\n";
                ROS_ERROR("INCORRECT INPUT IMAGE FRAME SIZE!");

            }

            else
            {
                try
                {
                    for (int i = 0; i < 8; i++)
                    { 
                        vertex_pixel[i] = M_int*p_bebop_vertices[i];
                        vertex_pixel[i] = vertex_pixel[i]/vertex_pixel[i].getZ();

                        vertex_pixel[i][0] = 1280 - vertex_pixel[i][0];
                        // vertex_pixel[i][1] = 480 - vertex_pixel[i][1];

                        std::cout << vertex_pixel[i][0] << "  " << vertex_pixel[i][1] << " " << vertex_pixel[i][2] << "\n";

                        cv::circle(cv_ptr->image, cv::Point(vertex_pixel[i][0], vertex_pixel[i][1]), 5, CV_RGB(255,0,0), -1);

                    }

                    std::cout << "\n";
                    for (int i = 0; i < 12; i++)
                    { 
                        cv::line(cv_ptr->image, cv::Point(vertex_pixel[connections[i][0]][0], vertex_pixel[connections[i][0]][1]), 
                                                cv::Point(vertex_pixel[connections[i][1]][0], vertex_pixel[connections[i][1]][1]), 
                                                CV_RGB(255,0,0), 2);  
                    }

                    // cv::line(cv_ptr->image, cv::Point(200, 50), cv::Point(500, 100), CV_RGB(255,0,0), 2);
                    // cv::circle(cv_ptr->image, cv::Point(50, 50), 10, CV_RGB(255,0,0));

                    sprintf(s, "img%05d.jpg", img_count);
                    frame_path = imgPath + s;
                    frame_bb_path = img_bb_path + "bb_" + s;
                    
                    std::cout << filename << "\n";   

                    outputFile << s << "," 
                            << secs_currrent << ","

                            << cb_relpose.xrel <<","
                            << cb_relpose.yrel <<","
                            << cb_relpose.zrel <<","
                    
                            << (int)(vertex_pixel[0][0]) << "," 
                            << (int)(vertex_pixel[0][1]) << "," 
                            
                            << (int)(vertex_pixel[1][0]) << ","
                            << (int)(vertex_pixel[1][1]) << ","

                            << (int)(vertex_pixel[2][0]) << ","
                            << (int)(vertex_pixel[2][1]) << ","  

                            << (int)(vertex_pixel[3][0]) << ","
                            << (int)(vertex_pixel[3][1]) << ","  

                            << (int)(vertex_pixel[4][0]) << ","
                            << (int)(vertex_pixel[4][1]) << ","  

                            << (int)(vertex_pixel[5][0]) << ","
                            << (int)(vertex_pixel[5][1]) << ","  

                            << (int)(vertex_pixel[6][0]) << ","
                            << (int)(vertex_pixel[6][1]) << ","  

                            << (int)(vertex_pixel[7][0]) << ","
                            << (int)(vertex_pixel[7][1]) << ","

                            << cb_relpose.pose_bebop[0] << ","
                            << cb_relpose.pose_bebop[1] << ","
                            << cb_relpose.pose_bebop[2] << ","

                            << cb_relpose.pose_bebop[3] << ","
                            << cb_relpose.pose_bebop[4] << ","
                            << cb_relpose.pose_bebop[5] << ","

                            << cb_relpose.pose_target[0] << ","
                            << cb_relpose.pose_target[1] << ","
                            << cb_relpose.pose_target[2] << ","

                            << cb_relpose.pose_target[3] << ","
                            << cb_relpose.pose_target[4] << ","
                            << cb_relpose.pose_target[5] 

                            <<std::endl;


                    imwrite(frame_path, cv_ptr_raw->image); 
                    imwrite(frame_bb_path, cv_ptr->image); 

                    std::cout << frame_path << "\n";
                    std::cout << frame_bb_path << "\n";

                    cv::imshow(OPENCV_WINDOW, cv_ptr->image);
                    cv::waitKey(3);

                    //     // // Output modified video stream
                    //     // // image_pub_.publish(cv_ptr->toImageMsg());

                    img_count++;

                    std::cout << img_count << "\n";


                    /* code */
                }

                catch(...)
                {
                    ROS_ERROR("ERROR!");
                    throw; 
                }

            }

        }
            
        else
        {
            ROS_ERROR("Frame does not exist!");
        }
            
    }
};

int main(int argc, char** argv)
{

    std::string wspacePath = ros::package::getPath("bebop_ros");
    std::fstream myfile(wspacePath + "/repo/dataset/count/frame_count.txt", std::ios_base::in);
    myfile >> img_count;

    ros::init(argc, argv, "bebop_sync_node");
    ROS_INFO("Visualization Initiated!\n");

    ImageConverter ic;

    ros::Rate rate(10);

    tf::TransformListener listener;

    tf::StampedTransform bebop_transform;
    tf::StampedTransform target_transform;

	while (ros::ok())
	{
        try 
        {
            listener.lookupTransform("/map","/vicon/bebop/bebop",ros::Time(0),bebop_transform);
            listener.lookupTransform("/map","/vicon/target/target",ros::Time(0),target_transform);
        }

        catch (tf::TransformException ex)
        {
            ROS_ERROR("%s",ex.what());
            goto stop;        
        }

        stop:

        ros::spinOnce();
        rate.sleep();
    }

    return 0;
}