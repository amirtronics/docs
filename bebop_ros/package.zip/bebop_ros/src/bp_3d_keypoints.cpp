/**
Software License Agreement (BSD)

\file     bp_3d_keypoints.cpp
\author   Amir Hossein Ebrahimnezhad <ebrahimnezhad@ualberta.ca>
\maintainer Martin Barczyk <mbarczyk@ualberta.ca>
\copyright Copyright (c) 2023, Mechatronic Systems Lab (University of Alberta), All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that
the following conditions are met:
 * Redistributions of source code must retain the above copyright notice, this list of conditions and the
   following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the
   following disclaimer in the documentation and/or other materials provided with the distribution.
 * Neither the name of Mechatronic Systems Lab nor the names of its contributors may be used to endorse or promote
   products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WAR-
RANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, IN-
DIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/


/*
 * Description:
 * This code take the odometry data of bebop and target drones from vicon
 * and generates the position of eight vertices of the 3D bounding box
 * of the target drone with respect to the bebop camera system of coordinates.
 *
*/


/*
Bounding Box Dimensions:
23cm depth, 9cm height, 31.5 width
COM: 12.5
*/

// Ros Headers 

#include <ros/ros.h>

// /tf Header Files 
#include<tf/transform_listener.h>
#include<tf/tf.h>
#include<tf/transform_datatypes.h>
#include<tf/transform_broadcaster.h>

//C++ I/O
#include <iostream>
#include <stdio.h>
#include <string>
#include <sstream>
#include <fstream> 

//Standard headers
#include <time.h>
#include <math.h>


//Custom Message Declaration 
#include <bebop_ros/vertices.h>
#include <bebop_ros/rpData.h>

//define TEST_FPS to enable framerate printout
#ifdef TEST_FPS
int startTime;
int counter;
#endif



tf::Vector3 rel_camera_pose;

void rel_pose(tf::StampedTransform, tf::StampedTransform, ros::Publisher, ros::Publisher);



int main(int argc, char** argv)
{
    ros::init(argc, argv, "bebop_keypoints_node");
    ros::NodeHandle nh;

    // /tf Variables //
    tf::TransformListener listener;

    tf::StampedTransform bebop_transform;
    tf::StampedTransform target_transform;

    // Publishers // 

    ros::Publisher vertex_pub = nh.advertise<bebop_ros::vertices>("/bebop/vertices", 1000);
    ros::Publisher rel_pub = nh.advertise<bebop_ros::rpData>("/bebop/rpData", 1000);


    // Node Rate //
    ros::Rate rate(25);

    while (ros::ok())
    {
        try
        {
            listener.lookupTransform("/map", "/vicon/target/target", ros::Time(0), target_transform);
            listener.lookupTransform("/map", "/vicon/bebop/bebop", ros::Time(0), bebop_transform);
        }
        catch (tf::TransformException ex)
        {
            ROS_ERROR("%s", ex.what());
            goto stop;
        }


        rel_pose(bebop_transform, target_transform, vertex_pub, rel_pub);



    stop:
        // Spin the Node // 

        ros::spinOnce();
        rate.sleep();
    }

    return 0;
}


void rel_pose(tf::StampedTransform bebop_transform, tf::StampedTransform target_transform, ros::Publisher vertex_pub, ros::Publisher rel_pub)
{
    //Initialize Constants and Variables
    int i;  //For-Loop Value 

    double yaw_target, pitch_target, roll_target; //Yaw,Pitch,Roll for /ARDrone_White frame
    double yaw_bebop, pitch_bebop, roll_bebop; //Yaw,Pitch,Roll for /ARDrone_Black frame
    double yaw_camera, pitch_camera, roll_camera;

    tf::Matrix3x3	R_bebop, R_target, R_camera, R_focal, R_y, R_z;
    tf::Vector3	p_bebop, p_target, p_target_cal, p_rel; // Position Vectors in World Coordinates

    // tf::Vector3 camera_offset(0.0, 0.0, 0.04);
    // tf::Vector3 p_bebop_com(0.0087, -0.056, 0.059);
    tf::Vector3 p_bebop_com(0.0, 0.0, 0.0);

    tf::Vector3 bebop_calibration;
    tf::Vector3 p_camera;

    tf::Vector3 p_temp[3];


    tf::Vector3 p_frame_target(0.0, 0.31, 0.04);
    tf::Vector3 p_target_com(0.1862, -0.2025, 0.044);
    tf::Vector3 target_calibration;

    tf::Vector3 p_target_vert[8];
    tf::Vector3 target_com_cal;
    tf::Vector3 p_target_vertices[8];

    p_target_vert[0] = { 0.0, 0.0, 0.0 };
    p_target_vert[1] = { 0.0, -0.315, 0.0 };
    p_target_vert[2] = { 0.0, -0.315, 0.09 };
    p_target_vert[3] = { 0.0, 0.0, 0.09 };

    p_target_vert[4] = { -0.23, 0.0, 0.0 };
    p_target_vert[5] = { -0.23, -0.315, 0.0 };
    p_target_vert[6] = { -0.23, -0.315, 0.09 };
    p_target_vert[7] = { -0.23, 0.0, 0.09 };

    target_com_cal = { 0.125, 0.1575, -0.04 };


    // p_target_vert[0] = {0.0, 0.0, 0.0};
    // p_target_vert[1] = {0.0, -0.254, 0.0};
    // p_target_vert[2] = {0.0, -0.254, 0.2667};
    // p_target_vert[3] = {0.0, 0.0, 0.2667};

    // p_target_vert[4] = {-0.3048, 0.0, 0.0};
    // p_target_vert[5] = {-0.3048, -0.254, 0.0};
    // p_target_vert[6] = {-0.3048, -0.254, 0.2667};
    // p_target_vert[7] = {-0.3048, 0.0, 0.2667};


    // target_com_cal = {0.0, 0.0, 0.0};


    // tf::Vector3 rpy_bebop_calib(-0.005, 0.0, 0.102);
    // tf::Vector3 rpy_target_calib(-0.009, 0.005, -0.003);

    // bebop_calibration = camera_offset - p_bebop_com;

    // target_calibration =  -p_target_com;


    bebop_ros::vertices vertices;
    bebop_ros::rpData relpose;

    //Rotation between /map to /ARDrone_Black frame 

    R_bebop.setRotation(bebop_transform.getRotation());
    R_target.setRotation(target_transform.getRotation());

    R_bebop.getRPY(roll_bebop, pitch_bebop, yaw_bebop);
    R_target.getRPY(roll_target, pitch_target, yaw_target);

    // R_target.setRPY(.0, .0, yaw_target);

    R_y.setRPY(0, -M_PI / 2.0, 0);
    R_z.setRPY(0, 0, -M_PI / 2.0);

    // R_bebop.setRPY(0.0, 0.0, yaw_bebop);
    // R_target.setRPY(roll_target-rpy_target_calib[0], pitch_target-rpy_target_calib[1], yaw_target-rpy_target_calib[2]);
    R_camera.setRPY(0, 0, yaw_bebop);
    R_focal = R_y * R_z; // for coordinates transformtion of world to pinhole coordinates

    // R_target.setRotation(target_transform.getRotation());

    //Position from /map to /ARDrone_Black frame 
    p_bebop = bebop_transform.getOrigin();

    //Position from /map to /ARDrone_White frame
    // p_target = target_transform.getOrigin() + target_calibration;
    p_target = target_transform.getOrigin();


    // p_camera = (p_bebop + R_bebop*bebop_calibration);
    p_camera = p_bebop;

    R_camera.getRPY(roll_camera, pitch_camera, yaw_camera);

    // std::cout << p_camera[0] << " " << p_camera[1] << " " << p_camera[2] 
    //    << " " << roll_camera*180.0/M_PI << " " << pitch_camera*180.0/M_PI << " " <<yaw_camera*180.0/M_PI << "\n";

    for (i = 0; i < 8; i++)
    {
        p_target_vertices[i] = R_focal.transpose() * R_camera.transpose() * (p_target + R_target * (target_com_cal + p_target_vert[i]) - p_camera);
        // p_target_vertices[i] = (p_target + R_target*(p_target_cal + p_target_vert[i]));
    }

    // p_rel = R_camera.transpose()*(p_target + R_target*(p_target_cal + target_com_cal) - p_camera); // To be Investigate!
    p_rel = R_camera.transpose() * (p_target - p_camera);


    std::cout << p_rel[0] << "\t" << p_rel[1] << "\t" << p_rel[2] << "\n";

    relpose.xrel = p_rel[0];
    relpose.yrel = p_rel[1];
    relpose.zrel = p_rel[2];

    relpose.pose_bebop = { p_camera[0], p_camera[1], p_camera[2], roll_bebop, pitch_bebop, yaw_bebop};
    relpose.pose_target = { p_target[0], p_target[1], p_target[2], roll_target, pitch_target, yaw_target};
    

    vertices.v0 = { p_target_vertices[0].getX(), p_target_vertices[0].getY(), p_target_vertices[0].getZ() };
    vertices.v1 = { p_target_vertices[1].getX(), p_target_vertices[1].getY(), p_target_vertices[1].getZ() };
    vertices.v2 = { p_target_vertices[2].getX(), p_target_vertices[2].getY(), p_target_vertices[2].getZ() };
    vertices.v3 = { p_target_vertices[3].getX(), p_target_vertices[3].getY(), p_target_vertices[3].getZ() };

    vertices.v4 = { p_target_vertices[4].getX(), p_target_vertices[4].getY(), p_target_vertices[4].getZ() };
    vertices.v5 = { p_target_vertices[5].getX(), p_target_vertices[5].getY(), p_target_vertices[5].getZ() };
    vertices.v6 = { p_target_vertices[6].getX(), p_target_vertices[6].getY(), p_target_vertices[6].getZ() };
    vertices.v7 = { p_target_vertices[7].getX(), p_target_vertices[7].getY(), p_target_vertices[7].getZ() };


    vertex_pub.publish(vertices);
    rel_pub.publish(relpose);

}