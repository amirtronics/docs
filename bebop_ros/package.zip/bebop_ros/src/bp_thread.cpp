#include <ros/ros.h>
#include <boost/thread.hpp>

// Thread function 1
void threadFunction1()
{
    while (ros::ok())
    {
        // Perform some work in thread 1
        ROS_INFO("Thread 1 is running");
        // Sleep for a certain duration
        boost::this_thread::sleep(boost::posix_time::milliseconds(500));
    }
}

// Thread function 2
void threadFunction2()
{
    while (ros::ok())
    {
        // Perform some work in thread 2
        ROS_INFO("Thread 2 is running");
        // Sleep for a certain duration
        boost::this_thread::sleep(boost::posix_time::milliseconds(2000));
    }
}

int main(int argc, char** argv)
{
    // Initialize ROS node
    ros::init(argc, argv, "multi_threaded_node");

    // Create ROS node handle
    ros::NodeHandle nh;

    // Create two thread objects and pass the thread functions
    boost::thread thread1(&threadFunction1);
    boost::thread thread2(&threadFunction2);

    // Spin ROS node
    ros::spin();

    // Wait for the threads to finish execution
    thread1.join();
    thread2.join();

    return 0;
}