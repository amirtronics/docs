/**
Software License Agreement (BSD)

\file     bp_solvepnp.cpp
\author   Amir Hossein Ebrahimnezhad <ebrahimnezhad@ualberta.ca>
\maintainer Martin Barczyk <mbarczyk@ualberta.ca>
\copyright Copyright (c) 2023, Mechatronic Systems Lab (University of Alberta), All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that
the following conditions are met:
 * Redistributions of source code must retain the above copyright notice, this list of conditions and the
   following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the
   following disclaimer in the documentation and/or other materials provided with the distribution.
 * Neither the name of Mechatronic Systems Lab nor the names of its contributors may be used to endorse or promote
   products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WAR-
RANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, IN-
DIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include <ros/ros.h>
#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>
#include <sensor_msgs/image_encodings.h>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>

#include "opencv2/core/core.hpp"
#include "opencv2/calib3d/calib3d.hpp"

#include <eigen3/Eigen/Dense>                
#include <eigen3/unsupported/Eigen/MatrixFunctions>

// /tf Header Files 
#include<tf/transform_listener.h>
#include<tf/tf.h>
#include<tf/transform_datatypes.h>
#include<tf/transform_broadcaster.h>

#include <time.h>
#include <math.h>

#include <unistd.h>
#include <vector>

//Custom Message Declaration 
#include <bebop_ros/spData.h>
#include <bebop_ros/rpData.h>
#include <bebop_ros/kpData.h>

#include <filter_digital.h>

std::vector<cv::Point2f> Generate2DPoints(int[]);
std::vector<cv::Point3f> Generate3DPoints();
void kpData_Callback(bebop_ros::kpData);

bool is_vicon_csv = false;
double t_start;
std::string kp_filter_act;

int kp_array[16];

Eigen::VectorXd sp_dat(7);


int main(int argc, char* argv[])
    {

    ros::init(argc, argv, "anafi_pnp_node");
    ros::NodeHandle nh("~");

    bebop_ros::kpData kp_pub_array;
    kp_pub_array.vert_kp = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

    nh.getParam("t_start_pursuit", t_start);
    nh.getParam("kp_filter", kp_filter_act);

    sleep((int) (t_start));

    ros::Publisher pnp_pub = nh.advertise<bebop_ros::rpData>("/bebop/relpos/pnp", 1000);
    ros::Publisher kp_pub = nh.advertise<bebop_ros::kpData>("/bebop/keypoints/filtered", 1000);

    ros::Subscriber kp_sub = nh.subscribe("/bebop/keypoints/raw",1000,kpData_Callback);

    ros::Rate rate(10);

    // Read points
    std::vector<cv::Point3f> objectPoints = Generate3DPoints();
    cv::Mat frame;

    cv::Mat cameraMatrix(3, 3, cv::DataType<double>::type);
    cv::setIdentity(cameraMatrix);

    cameraMatrix.at<double>(0, 0) = 738.195207; cameraMatrix.at<double>(0, 1) = 0.0; cameraMatrix.at<double>(0, 2) = 692.062813;
    cameraMatrix.at<double>(1, 0) = 0.0; cameraMatrix.at<double>(1, 1) = 725.632258; cameraMatrix.at<double>(1, 2) = 382.888215;
    cameraMatrix.at<double>(2, 0) = 0.0; cameraMatrix.at<double>(2, 1) = 0.0; cameraMatrix.at<double>(2, 2) = 1.0;

    // cameraMatrix.at<double>(0, 0) = 1280.0; cameraMatrix.at<double>(0, 1) = 0.0; cameraMatrix.at<double>(0, 2) = 640.0;
    // cameraMatrix.at<double>(1, 0) = 0.0; cameraMatrix.at<double>(1, 1) = 720.0; cameraMatrix.at<double>(1, 3) = 360.0;
    // cameraMatrix.at<double>(2, 0) = 0.0; cameraMatrix.at<double>(2, 1) = 0.0; cameraMatrix.at<double>(2, 3) = 1.0;

    std::cout << "Initial cameraMatrix: " << cameraMatrix << std::endl;

    cv::Mat distCoeffs(4, 1, cv::DataType<double>::type);
    distCoeffs.at<double>(0) = 0;
    distCoeffs.at<double>(1) = 0;
    distCoeffs.at<double>(2) = 0;
    distCoeffs.at<double>(3) = 0;

    cv::Mat rvec(3, 1, cv::DataType<double>::type);
    cv::Mat tvec(3, 1, cv::DataType<double>::type);

    tf::Vector3 p_pnp, p_rel, p_c_rel;
    tf::Matrix3x3	R_anafi, R_bebop, R_focal, R_x, R_z;

    bebop_ros::rpData pnp_pose;

    int i = 0;
    std::vector<cv::Point2f> imagePoints;

    filter::ButterworthFilter filter_x, filter_y, filter_z;

    // Butterworth filter_u0, filter_u1, filter_u2, filter_u3;
    // Butterworth filter_u4, filter_u5, filter_u6, filter_u7;

    // Butterworth filter_v0, filter_v1, filter_v2, filter_v3;
    // Butterworth filter_v4, filter_v5, filter_v6, filter_v7;

    filter::ButterworthFilter filter_kp[16];

    int filter_order = 3;


    // float b_x[3] = {0.0055,    0.0111,    0.0055};
    // float a_x[3] = {1.0000,   -1.7786,    0.8008};

    // float b_y[3] = {0.0055,    0.0111,    0.0055};
    // float a_y[3] = {1.0000,   -1.7786,    0.8008};

    // float b_z[3] = {0.0055,    0.0111,    0.0055};
    // float a_z[3] = {1.0000,   -1.7786,    0.8008};


    float b_x[3] = {0.0675,    0.1349,    0.0675};
    float a_x[3] = {1.0000,   -1.1430,    0.4128};

    float b_y[3] = {0.0675,    0.1349,    0.0675};
    float a_y[3] = {1.0000,   -1.1430,    0.4128};

    float b_z[3] = {0.0976,    0.1953,    0.0976};
    float a_z[3] = {1.0000,   -0.9428,    0.3333};

    filter_x.init(filter_order, a_x, b_x);
    filter_y.init(filter_order, a_y, b_y);
    filter_z.init(filter_order, a_z, b_z);

    for (unsigned int k = 0; i < 16; i++)
    {
        filter_kp[k].init(filter_order, a_x, b_x);
    }



    while (nh.ok())
    {
        if(kp_filter_act == "on") 
        {
            for (unsigned int k = 0; i < 16; i++)
            {
                kp_array[k] = filter_kp[k].filter(kp_array[k]);
            } 
        }

        imagePoints = Generate2DPoints(kp_array);

        cv::solvePnP(objectPoints, imagePoints, cameraMatrix, distCoeffs, rvec, tvec);

        p_pnp = { tvec.at<double>(0), tvec.at<double>(1), tvec.at<double>(2) };

        R_x.setRPY(M_PI / 2.0, 0, 0);
        R_z.setRPY(0, 0, M_PI / 2.0);

        R_focal = R_x * R_z;

        // p_rel = R_anafi.transpose()*R_bebop*R_focal*p_pnp;
        p_rel = R_focal.transpose() * p_pnp;

        // p_rel = {p_rel[0], -p_rel[1], p_rel[2]};
        
        
        // std::cout << "x-rel = " << std::stod(csv_data[i][2])/10.0 << " y-rel = " << std::stod(csv_data[i][3])/10.0 << " z-rel = " << std::stod(csv_data[i][4])/10.0 << "\n";
        // std::cout << "x-pnp = " << p_rel[0] << " x-pnp = " << p_rel[1] << " x-pnp = " << p_rel[2] << "\n";
        // std::cout << i << "\tyaw_anafi: " << yaw_anafi * 180 / M_PI << "   y_bebop: " << yaw_bebop * 180 / M_PI << "\n";
        // std::cout << "x_rel: " << p_c_rel[0] << "   y_rel: " << p_c_rel[1] << "   z_rel: " << p_c_rel[2] << "\n";
        
        std::cout << "x_pnp: " << p_rel[0] << "   y_pnp: " << p_rel[1] << "   z_pnp: " << p_rel[2] << "\n";
        std::cout << "x_tvec: " << tvec.at<double>(0) << "y_tvec: " << tvec.at<double>(1) << "z_tvec: " << tvec.at<double>(2) << "\n";
        std::cout << "phi: " << rvec.at<double>(0) << "theta: " << rvec.at<double>(1) << "psi: " << rvec.at<double>(2) << "\n";
        std::cout << i << "\n------------------------------\n";

        std::vector<cv::Point2f> projectedPoints;
        cv::projectPoints(objectPoints, rvec, tvec, cameraMatrix, distCoeffs, projectedPoints);
        
        for(unsigned int k = 0; k < projectedPoints.size(); ++k)
        {
            std::cout << "Image point: " << imagePoints[k] << " Projected to " << projectedPoints[k] << std::endl;
        }

        pnp_pose.xrel = filter_x.filter(p_rel[0]);
        pnp_pose.yrel = filter_y.filter(p_rel[1]);
        pnp_pose.zrel = filter_z.filter(p_rel[2]);

        pnp_pub.publish(pnp_pose);

        if (kp_filter_act == "on")
        {
            for(int j = 0; j < 16; j++)
            {
                kp_pub_array.vert_kp[j] = kp_array[j];
            }

            kp_pub.publish(kp_pub_array);
        }

        ros::spinOnce();

        rate.sleep();

        i++;

    }
    return 0;
}

void kpData_Callback(bebop_ros::kpData kp_topic) 
{

    for(int i = 0; i < 16; i++)
    {
        kp_array[i] = kp_topic.vert_kp[i];
    }

}


// void filter_keypoints(int kp_array_[], Butterworth filter_[])
// {


//     for (int i = 0; i < 16; i++)
//     {
//         kp_array[i] = filter_->filter(kp_array_[i]);
//     }

// }

std::vector<cv::Point2f> Generate2DPoints(int kp_array_[])
{
    std::vector<cv::Point2f> points;
    float x, y;

    for (int i = 0; i < 16; i += 2)
    {
        x = (float) kp_array_[i];
        y = (float) kp_array_[i+1];
        points.push_back(cv::Point2f(x, y));
    }


    // float x, y;
    // float u0, v0, u1, v3, u4, v4, u5, v7, h1, w1, h2, w2;

    // u0 = (float) kp_array_[0];
    // v0 = (float) kp_array_[1];

    // u1 = (float) kp_array_[2];
    // v3 = (float) kp_array_[7];

    // u4 = (float) kp_array_[8];
    // v4 = (float) kp_array_[9];

    // u5 = (float) kp_array_[10];

    // v7 = (float) kp_array_[15];

    // h1 = v3-v0;
    // w1 = u1-u0;

    // h2 = v7-v4;
    // w2 = u5-u4;

    // points.push_back(cv::Point2f(u0, v0));
    // points.push_back(cv::Point2f(u0+w1, v0));
    // points.push_back(cv::Point2f(u0+w1, v0+h1));
    // points.push_back(cv::Point2f(u0, v0+h1));

    // points.push_back(cv::Point2f(u4, v4));
    // points.push_back(cv::Point2f(u4+w2, v4));
    // points.push_back(cv::Point2f(u4+w2, v4+h2));
    // points.push_back(cv::Point2f(u4, v4+h2));

    // for(unsigned int i = 0; i < points.size(); ++i)
    //   {
    //   std::cout << points[i] << std::endl;
    //   }

    return points;
}


std::vector<cv::Point3f> Generate3DPoints()
{
    std::vector<cv::Point3f> points;


    float x, y, z;

    cv::Point3f vec_c(-0.1575, 0.045, 0.125);

    x = 0.0; y = 0.0; z = 0.0;
    points.push_back(cv::Point3f(x, y, z) + vec_c);

    x = 0.315; y = 0.0; z = 0.0;
    points.push_back(cv::Point3f(x, y, z) + vec_c);

    x = 0.315; y = -0.09; z = 0.0;
    points.push_back(cv::Point3f(x, y, z) + vec_c);

    x = 0.0; y = -0.09; z = 0.0;
    points.push_back(cv::Point3f(x, y, z) + vec_c);

    // 

    x = 0.0; y = 0.0; z = -0.23;
    points.push_back(cv::Point3f(x, y, z) + vec_c);

    x = 0.315; y = 0.0; z = -0.23;
    points.push_back(cv::Point3f(x, y, z) + vec_c);

    x = 0.315; y = -0.09; z = -0.23;
    points.push_back(cv::Point3f(x, y, z) + vec_c);

    x = 0.0; y = -0.09; z = -0.23;
    points.push_back(cv::Point3f(x, y, z) + vec_c);

    //


    for (unsigned int i = 0; i < points.size(); ++i)
    {
        std::cout << points[i] << std::endl;
    }

    return points;
}
