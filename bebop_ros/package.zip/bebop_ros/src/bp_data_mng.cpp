/**
Software License Agreement (BSD)

\file     bp_data_mng.cpp
\author   Amir Hossein Ebrahimnezhad <ebrahimnezhad@ualberta.ca>
\maintainer Martin Barczyk <mbarczyk@ualberta.ca>
\copyright Copyright (c) 2023, Mechatronic Systems Lab (University of Alberta), All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that
the following conditions are met:
 * Redistributions of source code must retain the above copyright notice, this list of conditions and the
   following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the
   following disclaimer in the documentation and/or other materials provided with the distribution.
 * Neither the name of Mechatronic Systems Lab nor the names of its contributors may be used to endorse or promote
   products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WAR-
RANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, IN-
DIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

//ROS Headers

#include <ros/ros.h>
#include <geometry_msgs/Twist.h>
#include <geometry_msgs/TransformStamped.h>
#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>
#include <sensor_msgs/image_encodings.h>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <ros/package.h>

#include<tf/transform_listener.h>
#include<tf/tf.h>
#include<tf/transform_datatypes.h>
#include<tf/transform_broadcaster.h>

#include <eigen3/Eigen/Dense>                
#include <eigen3/unsupported/Eigen/MatrixFunctions>

// Header Files Specific to the project
#include"../include/colour.h"
#include"../include/twistops.hpp" 

//Custom Libraries
#include <csv_mng.h>

//C++ I/O
#include <iostream>
#include <stdio.h>
#include <string>
#include <sstream>
#include <fstream> 

//Standard headers
#include <time.h>
#include <math.h>
#include <unistd.h>
#include <sys/stat.h>
#include <ctime>
#include <stdlib.h>
#include <filesystem>


// Global Variables

// static const std::string OPENCV_WINDOW = "Image window";
Eigen::VectorXd sp_dat(7);
Twist cmd_vel;

double t_start;
int kp_array[16];


class PursuitData
{
    ros::NodeHandle nh_;
    ros::NodeHandle private_nh;

    image_transport::ImageTransport it_;
    image_transport::Subscriber image_sub_, image_raw_sub_, image_realsense_sub_;

    ros::Subscriber sp_sub, pid_sub, kp_sub;

public:

    // Objects
    CSVManager csvManager_;
    
    double secs_init = ros::Time::now().toSec();
    double secs_currrent;

    double pose_anafi[6];
    double pose_bebop[6];

    char s[25];
    char t_char[10];

    double roll_a, pitch_a, yaw_a; // Roll, Pitch, Yaw for /Target frame
    double roll_b, pitch_b, yaw_b; // Roll, Pitch, Yaw for /Bebop frame

    tf::Vector3	p_target, p_bebop;
    tf::Matrix3x3 R_target, R_bebop;

    std::string c_month, c_day, c_hour, c_minute;
    std::string folder_path, data_path, csv_path, frame_raw_path, img_path;
    std::string pursuit_activation;
    std::string frame_sub_name, frame_kp_name;
    std::string kp_filter_act;
    std::string filename;
    std::vector<std::string> headers = 
    { "Frame ID", "Time (s)", "x_bebop [m]", "y_bebop [m]", "z_bebop [m] ", "roll_bebop [rad]", "pitch_bebop [rad]", "yaw_bebop [rad]", "x_target [m]", "y_target [m]", "z_target [m] ", "roll_target [rad]", "pitch_target [rad]", "yaw_target [rad]", "sp_x [m]", "sp_y [m]", "sp_z [m]", "sp_yaw [rad]", "PID_x", "PID_y", "PID_z", "PID_yaw"};

    std::string workspacePath = ros::package::getPath("bebop_ros");
    
    cv_bridge::CvImagePtr cv_raw_ptr, cv_rsense_ptr;



    PursuitData()
        : private_nh("~"),
          it_(nh_)
    {

        private_nh.getParam("pursuit_activation", pursuit_activation);
        private_nh.getParam("t_start_pursuit", t_start);


        sleep((int) (t_start));
        
        ROS_INFO("Starting...\n");
        ROS_INFO("OpenCV version: %s\n",CV_VERSION);

        // Obtaining Current Date and Time
        time_t now = time(0);
        tm *ltm = localtime(&now);


        if (!workspacePath.empty()) {
            std::cout << "Catkin workspace path: " << workspacePath << std::endl;
        } else {
            std::cout << "Failed to retrieve Catkin workspace path." << std::endl;
        }

        c_day = std::to_string(ltm->tm_mday);
        c_month = std::to_string(1 + ltm->tm_mon);
        c_hour = std::to_string(ltm->tm_hour);
        c_minute = std::to_string(ltm->tm_min);

        sprintf(t_char, "%02d_%02d_%02d_%02d", 1 + ltm->tm_mon, ltm->tm_mday, ltm->tm_hour, ltm->tm_min);


        // Directory Path
        folder_path = workspacePath + "/repo/pursuit/";
        data_path =  folder_path+ "pursuit_" + pursuit_activation + "_" + t_char;
        csv_path = data_path + "/csv";
        frame_raw_path = data_path + "/frames_raw/";
        filename = csv_path + "/pursuit_data.csv";
        csvManager_.addPath(filename, headers); // Add path for csv file

        // Creating Directory

        int status = mkdir(data_path.c_str(),0777);

        if (!status)
        {
            printf("Directory created\n");

            mkdir(csv_path.c_str(),0777);
            mkdir(frame_raw_path.c_str(),0777);

        }
            
        else 
        {
            printf("Unable to create directory\n");
            exit(1);
        }

        // Subscribe to input video feed and publish output video feed


        image_raw_sub_ = it_.subscribe("/bebop/image_raw", 1000, &PursuitData::image_raw_Cb, this);
        sp_sub  = nh_.subscribe("/bebop/spData", 1000, &PursuitData::spCb, this);
        pid_sub  = nh_.subscribe("/bebop/cmd_vel", 1000, &PursuitData::pidCb, this);
    }

    ~PursuitData()
    {
        csvManager_.save();
    }
 
    void image_raw_Cb(const sensor_msgs::ImageConstPtr& msg)
    {
        try
        {
            this->cv_raw_ptr = cv_bridge::toCvCopy(msg, sensor_msgs::image_encodings::BGR8);
        }
        
        catch (cv_bridge::Exception& e)
        {
            ROS_ERROR("cv_bridge exception: %s", e.what());
            return;
        }
        
    }

    void spCb(geometry_msgs::Pose sp_topic)
    {
        sp_dat[0] = sp_topic.position.x;
        sp_dat[1] = sp_topic.position.y;
        sp_dat[2] = sp_topic.position.z;

        sp_dat[3] = sp_topic.orientation.z;
    }

    void pidCb(Twist cmd_msg)
    {
        cmd_vel.linear = cmd_msg.linear;
        cmd_vel.angular = cmd_msg.angular;
    }

    void save_data(tf::StampedTransform target_transform, tf::StampedTransform bebop_transform, double sec_now, int& img_count)
    {

            R_target.setRotation(target_transform.getRotation());
            R_bebop.setRotation(bebop_transform.getRotation());
            
            R_target.getRPY(roll_a,pitch_a,yaw_a);
            R_bebop.getRPY(roll_b,pitch_b,yaw_b);

            p_target = target_transform.getOrigin();
            p_bebop = bebop_transform.getOrigin();

            sprintf(s, "img_raw_%05d.jpg", img_count);
            img_path = frame_raw_path + s;
            imwrite(img_path, this->cv_raw_ptr->image); 

            // cv::imshow(OPENCV_WINDOW, this->cv_ptr->image);
            // cv::waitKey(3);

            double data_[] = {sec_now, p_bebop[0], p_bebop[1], p_bebop[2], roll_b, pitch_b, yaw_b, p_target[0], p_target[1], p_target[2], roll_a, pitch_a, yaw_a, sp_dat[0], sp_dat[1], sp_dat[2], sp_dat[3], cmd_vel.linear.x, cmd_vel.linear.y, cmd_vel.linear.z, cmd_vel.angular.z};
            csvManager_.addRow(transformToVector(s, data_, 21));

            img_count++;
            std::cout << "Image Saved: " << img_count << "\n";
    }

    std::vector<std::string> transformToVector(char* frame_name, const double* arr, int size)
    {
        std::vector<std::string> result;
        result.reserve(size);

        result.emplace_back(frame_name);
        for (int i = 0; i < size; ++i)
        {
        result.emplace_back(std::to_string(arr[i]));
        }
        return result;
    }

};

int main(int argc, char** argv)
{

    ros::init(argc, argv, "bebop_pursuit_data_node");
    ROS_INFO("Visualization Initiated!\n");

    int img_count = 0;
    int &img_count_ref = img_count;

    PursuitData pursuit_data;


    double secs_init, secs_currrent;

    secs_init = ros::Time::now().toSec();

    ros::Rate rate(10);

    // /tf Variables //
    tf::TransformListener listener;

    tf::StampedTransform target_transform;
    tf::StampedTransform bebop_transform;

    while (ros::ok())
	{

        secs_currrent = ros::Time::now().toSec() - secs_init;

        try
        {
            listener.lookupTransform("/map","/vicon/bebop/bebop",ros::Time(0),bebop_transform);
            listener.lookupTransform("/map","/vicon/target/target",ros::Time(0),target_transform);
        }
        catch (tf::TransformException ex) 
        {
            ROS_ERROR("%s",ex.what());
            goto stop;
        }

        if (pursuit_data.cv_raw_ptr)
        {

            if(pursuit_data.cv_raw_ptr->image.rows != 480 || pursuit_data.cv_raw_ptr->image.cols != 856)
            {
                std::cout << pursuit_data.cv_raw_ptr->image.rows << " " << pursuit_data.cv_raw_ptr->image.cols << "\n";
                ROS_ERROR("INCORRECT INPUT IMAGE FRAME SIZE!");
                goto stop;
            }

            pursuit_data.save_data(target_transform, bebop_transform, secs_currrent, img_count_ref);
        }

        stop:
        ros::spinOnce(); 
        rate.sleep();
        
    }

    // ros::spin();
    
    return 0;
}