/*
 * This file contains the main() function for the UAVControl executable, as well as some of its more
 * immediate functions.
 *
 * UAVControl displays the drone's video feed and allows keyboard control.
 * To control the drone using the keyboard, the video feed must be the active window 
 * (ie. have the mouse hovering on it)
 *
 * Controls are as follows:
 *
 *      s: Left
 *      f: Right
 *      e: Forwards
 *      d: Backwards
 *
 *      w: Rotate Left
 *      r: Rotate Right
 *
 *      q: Up
 *      a: Down
 *
 *      y: Takeoff
 *      h: Land
 *
 *      x: Quit (better not to do this while flying)
 *
 * 
 * Author:      Adam Casey,     acasey@ualberta.ca
 * Maintainer:  Martin Barczyk, mbarczyk@ualberta.ca
 */

//ROS Headers
#include <geometry_msgs/Twist.h>
#include <sensor_msgs/Image.h>
#include <std_msgs/Empty.h>

#include <ros/ros.h>

#include <cv_bridge/cv_bridge.h>

//C++ I/O
#include <iostream>
#include <stdio.h>

//Standard headers
#include <time.h>
#include <math.h>

//Header files specific to this project
#include "../include/colour.h"
#include "../include/twistops.hpp"

#include <opencv2/core/core.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/objdetect/objdetect.hpp>
#include <opencv2/highgui/highgui.hpp>

//#define TEST_FPS to enable framerate printout
//I think this functionality may be broken
#ifdef TEST_FPS
    int startTime;
    int counter;
#endif

const int MOVE_TIME = 100; //ms
////Program constants
//Number of seconds to wait for the video stream 
const int TIMEOUT = 15;


void imageConvert (const sensor_msgs::Image::ConstPtr&, cv::Mat* frame);
const std::string window_name = "Capture - UAV detection";
char screenCheck (cv::Mat& frame);
void moveFunc (ros::Publisher, Twist, char, cv::Mat& frame);
bool processInputs (int argc, char** argv);

int main( int argc, char** argv ){
    
    //Check for command-line arguments, quits if invalid.
    if (processInputs(argc, argv))
        return -1;

    ros::init(argc, argv, "bebopUAV");
    
    ros::NodeHandle nh;
    
    ROS_INFO("Starting...\n");
    ROS_INFO("OpenCV version: %s\n",CV_VERSION);
    
    //Subscribe to video stream
    cv::Mat frame;
    ros::Subscriber sub = nh.subscribe<sensor_msgs::Image>("/bebop/image_raw", 10,
                                                            boost::bind(imageConvert, _1, &frame));
    ros::spinOnce();

    //Wait for a message
    unsigned long start = time(NULL);

    while(frame.empty() && ros::ok() && time(NULL) - start <= TIMEOUT){
        ROS_INFO("Waiting for frame...%li seconds\n", time(NULL) - start);

        //One-second delay
        unsigned long prev = time(NULL);

        while (frame.empty() && prev - time(NULL) < 1){
            ros::spinOnce();
        }
    }

    //Check if loop was successful
    if (!ros::ok()){
        return(0);
    }else if (time(NULL) - start > 10){
        ROS_ERROR("Timeout getting frame --- "
                "Ensure that driver is running and network is connected before trying again.");
        return -1;
    }

    //Publishers to interact with the driver.
    ros::Publisher controller   = nh.advertise<Twist>("/bebop/cmd_vel", 1);
    ros::Publisher takeoff      = nh.advertise<std_msgs::Empty>("/bebop/takeoff", 1);
    ros::Publisher land         = nh.advertise<std_msgs::Empty>("/bebop/land", 1);

    //Declaring messages
    Twist control;
    Twist blank; //Blank message used to reset control.
    std_msgs::Empty fly;

    ROS_INFO(ANSI_BOLD ANSI_GREEN "Starting!\n" ANSI_RESET ANSI_NORMAL);
    ROS_INFO("\nHit 'x' to quit\n");

    #ifdef TEST_FPS
        counter = 0;
        startTime = time(NULL);
    #endif

    //Display the most recently converted frame and do keyboard control.
    for (char key = -1; key != 'x' && ros::ok(); key = screenCheck(frame)){
        if (key != -1){
            //Respond to key presses with motion.
            switch(key){
                case('s'): control.linear.y = 1;    break;
                case('f'): control.linear.y = -1;   break;
                case('e'): control.linear.x = 1;    break;
                case('d'): control.linear.x = -1;   break;

                case('w'): control.angular.z = 1;   break;
                case('r'): control.angular.z = -1;  break;

                case('c'): control.angular.z = 1;   break;
                case('b'): control.angular.z = -1;  break;

                case('q'): control.linear.z = 1;    break;
                case('a'): control.linear.z = -1;   break;

                case('y'): takeoff.publish(fly);    break;
                case('h'): land.publish(fly);       break;
            }
            moveFunc(controller, control, key, frame);

            //Stop
            control = blank;
            moveFunc(controller, blank, 0, frame);
        }
    }
    
    land.publish(fly);
    return 0;
}

//Listens for ros image messages and converts from ros sensor_msgs::Image 
//to cv_bridge::CvIMagePtr to cv::Mat
void imageConvert(const sensor_msgs::Image::ConstPtr& msg, cv::Mat* frame){
    
    cv_bridge::CvImagePtr cv_ptr;
    
    try{
        cv_ptr = cv_bridge::toCvCopy(msg, sensor_msgs::image_encodings::BGR8);
    }catch (cv_bridge::Exception& e){
        ROS_ERROR("cv_bridge exception: %s", e.what());
        return;
    }    
    
    *frame = cv_ptr->image;

    // imwrite("/home/bluesky/catkin_ws/src/bebop_ros/repo/frame/frame720.jpg", cv_ptr->image); 
}

//Publishes the passes command message via the passed publisher, for MOVE_TIME milliseconds.
void moveFunc (ros::Publisher pub, Twist cmd, char passedKey, cv::Mat& frame){
    for(char key = passedKey; key == passedKey && ros::ok(); key = cv::waitKey(MOVE_TIME)){
        
        pub.publish(cmd);
        ros::spinOnce();
        imshow(window_name, frame);
    }
}

//Spins to update ros, shows the most recently processed frame,
//and returns any key pressed during this time
char screenCheck(cv::Mat& frame){
    //Pull the next frame into imageConvert
    ros::spinOnce();
    
    //Display the video
    imshow(window_name, frame);
    
    return cv::waitKey(1);
}

// Deals with the passed parameters by printing a help menu or exiting if the parameter is invalid.
// Inline because only one occurence.
inline bool processInputs(int argc, char** argv){
     if (argc > 1){
             if (!(strcmp(argv[1],"-h") && strcmp(argv[1],"--help"))){
                         printf("\nUse -h or --help for options:\n\n"

                    "Controls: \n\n"

                        "\ts: \tLeft\n"
                        "\tf: \tRight\n"
                        "\te: \tForwards\n"
                        "\td: \tBackwards\n\n"

                        "\tw: \tRotate Left\n"
                        "\tr: \tRotate Right\n"

                        "\tq: \tUp\n"
                        "\ta: \tDown\n\n"

                        "\ty: \tTakeoff\n"
                        "\th: \tLand\n\n"

                        "\tx: \tQuit (better not to do this while flying)\n\n");
            return(1);
        }else if (!strcmp(argv[1],"default")){
            return 0;
        }else{
            ROS_ERROR("Bad input!");
            ROS_ERROR("%s is not a valid parameter\n", argv[1]);
            return -1;
        }
    }
    return 0;
}
