/**
Software License Agreement (BSD)

\file     af_pursuit_data.cpp
\author   Amir Hossein Ebrahimnezhad <ebrahimnezhad@ualberta.ca>
\maintainer Martin Barczyk <mbarczyk@ualberta.ca>
\copyright Copyright (c) 2023, Mechatronic Systems Lab (University of Alberta), All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that
the following conditions are met:
 * Redistributions of source code must retain the above copyright notice, this list of conditions and the
   following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the
   following disclaimer in the documentation and/or other materials provided with the distribution.
 * Neither the name of Mechatronic Systems Lab nor the names of its contributors may be used to endorse or promote
   products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WAR-
RANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, IN-
DIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

//ROS Headers

#include <ros/ros.h>
#include <geometry_msgs/Twist.h>
#include <geometry_msgs/TransformStamped.h>
#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>
#include <sensor_msgs/image_encodings.h>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>

#include<tf/transform_listener.h>
#include<tf/tf.h>
#include<tf/transform_datatypes.h>
#include<tf/transform_broadcaster.h>

#include <eigen3/Eigen/Dense>                
#include <eigen3/unsupported/Eigen/MatrixFunctions>


//Custom Message Declaration 
#include <bebop_ros/spData.h>
#include <bebop_ros/rpData.h>
#include <bebop_ros/vertices.h>
#include <bebop_ros/kpData.h>

// Header Files Specific to the project
#include"../include/colour.h"
#include"../include/twistops.hpp" 
#include <csv_mng.h>


//C++ I/O
#include <iostream>
#include <stdio.h>
#include <string>
#include <sstream>
#include <fstream> 

//Standard headers
#include <time.h>
#include <math.h>

#include <unistd.h>
#include <sys/stat.h>

#include <ctime>


// Global Variables

// static const std::string OPENCV_WINDOW = "Image window";
bebop_ros::rpData pnp_dat, rel_dat;
Eigen::VectorXd sp_dat(7);
Twist cmd_vel;

double t_start;
int kp_array[16];


class PursuitData
{
    ros::NodeHandle nh_;
    ros::NodeHandle private_nh;

    image_transport::ImageTransport it_;
    image_transport::Subscriber image_sub_, image_raw_sub_, image_realsense_sub_;

    ros::Subscriber sp_sub, pid_sub, pnp_sub, rel_sub, kp_sub;

public:

    
    double secs_init = ros::Time::now().toSec();
    double secs_currrent;

    double pose_anafi[6];
    double pose_target[6];

    char s[25];
    char t_char[10];

    double roll_a, pitch_a, yaw_a; // Roll, Pitch, Yaw for /Anafi frame
    double roll_b, pitch_b, yaw_b; // Roll, Pitch, Yaw for /Bebop frame

    tf::Vector3	p_anafi, p_target;

    tf::Matrix3x3	R_anafi, R_target;

    std::string c_month, c_day, c_hour, c_minute;
    std::string folder_path, data_path, csv_path, frame_path, img_path, frame_raw_path, frame_rsense_path, frame_bb_path, graph_path, axis_graph_path, pursuit_graph_path;
    std::string pursuit_actvation, pursuit_type, visualization_type, realsense_activation;
    std::string frame_sub_name, frame_kp_name;
    std::string kp_filter_act;
    std::string graph_axis[3] = {"/x/", "/y/", "/z/"};
    std::string graph_pursuit_axis[3] = {"/pursuit_x/", "/pursuit_y/", "/pursuit_z/"};

    std::string vis_array[4] = {"/anafi/frames", "/anafi/frames_mask", "/anafi/frames_kp", "/anafi/frames_bb"};
    std::ofstream outputFile;
    std::string filename;

    cv_bridge::CvImagePtr cv_ptr, cv_raw_ptr, cv_rsense_ptr;

    PursuitData()
        : private_nh("~"),
          it_(nh_)
    {

        private_nh.getParam("pursuit_actvation", pursuit_actvation);
        private_nh.getParam("pursuit_type", pursuit_type);
        private_nh.getParam("visualization_type", visualization_type);
        private_nh.getParam("realsense_activation", realsense_activation);
        private_nh.getParam("t_start_pursuit", t_start);
        private_nh.getParam("kp_filter", kp_filter_act);

        sleep((int) (t_start));
        
        std::cout << pursuit_actvation << "\n";

        ROS_INFO("Starting...\n");
        ROS_INFO("OpenCV version: %s\n",CV_VERSION);

        // Obtaining Current Date and Time

        time_t now = time(0);
        tm *ltm = localtime(&now);




        c_day = std::to_string(ltm->tm_mday);
        c_month = std::to_string(1 + ltm->tm_mon);
        c_hour = std::to_string(ltm->tm_hour);
        c_minute = std::to_string(ltm->tm_min);

        sprintf(t_char, "%02d_%02d_%02d_%02d", 1 + ltm->tm_mon, ltm->tm_mday, ltm->tm_hour, ltm->tm_min);

        
        // Directory Path
        
        folder_path = "/home/bluesky/catkin_ws/src/bebop_ros/src/repo/pursuit/";
        data_path =  folder_path+ "pursuit_" + pursuit_actvation + "_" + visualization_type + "_" + t_char;
        csv_path = data_path + "/csv";
        frame_path = data_path + "/frames/";
        frame_raw_path = data_path + "/frames_raw/";
        frame_rsense_path = data_path + "/frames_realsense/";
        frame_bb_path =  data_path + "/frames_bb/";
        graph_path = data_path + "/frames_graph/";

        filename = csv_path + "/pursuit_data.csv";

        // Creating Directory

        int status = mkdir(data_path.c_str(),0777);

        if (!status)
        {
            printf("Directory created\n");

            mkdir(csv_path.c_str(),0777);
            mkdir(frame_path.c_str(),0777);
            mkdir(frame_raw_path.c_str(),0777);
            mkdir(frame_rsense_path.c_str(),0777);
            mkdir(graph_path.c_str(),0777);
            mkdir(frame_bb_path.c_str(),0777);

            for(int k = 0; k < 3; k++)
            {
                axis_graph_path = data_path + "/frames_graph" + graph_axis[k];
                pursuit_graph_path = data_path + "/frames_graph" + graph_pursuit_axis[k];

                mkdir(axis_graph_path.c_str(),0777);
                mkdir(pursuit_graph_path.c_str(),0777);
            }

        }
            
        else 
        {
            printf("Unable to create directory\n");
            exit(1);
        }

        // Subscribe to input video feed and publish output video feed

        if (visualization_type == "raw")  frame_sub_name = vis_array[0];
        else if (visualization_type == "mask")  frame_sub_name = vis_array[1];
        else if (visualization_type == "kp")  frame_sub_name = vis_array[2];
        else if (visualization_type == "pnp")  frame_sub_name = vis_array[3];

        if (kp_filter_act == "on")  frame_kp_name = "/bebop/keypoints/filtered";
        else if (kp_filter_act == "off")  frame_kp_name = "/bebop/keypoints/raw";


        image_sub_ = it_.subscribe(frame_sub_name, 1, &PursuitData::imageCb, this);
        image_raw_sub_ = it_.subscribe("/bebop/image_raw", 1, &PursuitData::image_raw_Cb, this);
        image_realsense_sub_ = it_.subscribe("/usb_cam/image_raw", 1, &PursuitData::image_rsense_Cb, this);
        sp_sub  = nh_.subscribe("/bebop/spData", 1000, &PursuitData::spCb, this);
        pid_sub  = nh_.subscribe("/cmd_vel", 1000, &PursuitData::pidCb, this);
        pnp_sub  = nh_.subscribe("/bebop/rpData/pnp", 1000, &PursuitData::pnpCb, this);
        rel_sub  = nh_.subscribe("/bebop/rpData/vicon", 1000, &PursuitData::relCb, this);
        kp_sub = nh_.subscribe(frame_kp_name,1000, &PursuitData::kpData_Callback, this);
        outputFile.open(filename, std::ios::app);

        outputFile  << "Frame ID" << "," 

                    << "Time (sec)" << "," 

                    << "x_anafi [m]" << "," // 2
                    << "y_anafi [m]" << ","
                    << "z_anafi [m]" << ","

                    << "roll_anafi [rad]" << "," // 5
                    << "pitch_anafi [rad]" << ","
                    << "yaw_anafi [rad]" << ","

                    << "x_target [m]" << "," // 8
                    << "y_target [m]" << ","
                    << "z_target [m]" << ","  

                    << "roll_target [rad]" << "," // 11
                    << "pitch_target [rad]" << ","
                    << "yaw_target [rad]" << ","

                    // Setpoint Data

                    << "x_sp [m]" << "," // 14
                    << "y_sp [m]" << ","
                    << "z_sp [m]" << ","  
                    << "yaw_sp [rad]" << ","                  

                    // Vicon relative pose
                    << "x_rel [m]" << "," // 18
                    << "y_rel [m]" << ","
                    << "z_rel [m]" << ","

                    // Estimated relative pose
                    << "x_est [m]" << "," // 21
                    << "y_est [m]" << ","
                    << "z_est [m]" << "," 

                    // PID Data
                    <<" PID_x [%]" <<"," // 24
                    << "PID_y [%]" << "," 
                    << "PID_z [%]" <<","
                    << "PID_yaw [%]" <<","

                    // Vertices Data // 28
                    << "v0 [u]" << ","
                    << "v0 [v]" << ","

                    << "v1 [u]" << ","
                    << "v1 [v]" << ","

                    << "v2 [u]" << ","
                    << "v2 [v]" << ","

                    << "v3 [u]" << ","
                    << "v3 [v]" << ","

                    << "v4 [u]" << ","
                    << "v4 [v]" << ","

                    << "v5 [u]" << ","
                    << "v5 [v]" << ","

                    << "v6 [u]" << ","
                    << "v6 [v]" << ","

                    << "v7 [u]" << ","
                    << "v7 [v]"

                    << std::endl;

        // cv::namedWindow(OPENCV_WINDOW);


    }

    ~PursuitData()
    {
        // cv::destroyWindow(OPENCV_WINDOW);

        outputFile.close();
    }
 
    
    void imageCb(const sensor_msgs::ImageConstPtr& msg)
    {

        secs_currrent = ros::Time::now().toSec() - secs_init;

        try
        {
            this->cv_ptr = cv_bridge::toCvCopy(msg, sensor_msgs::image_encodings::BGR8);
        }
        
        catch (cv_bridge::Exception& e)
        {
            ROS_ERROR("cv_bridge exception: %s", e.what());
            return;
        }
        
    }

    void image_raw_Cb(const sensor_msgs::ImageConstPtr& msg)
    {


        try
        {
            this->cv_raw_ptr = cv_bridge::toCvCopy(msg, sensor_msgs::image_encodings::BGR8);
        }
        
        catch (cv_bridge::Exception& e)
        {
            ROS_ERROR("cv_bridge exception: %s", e.what());
            return;
        }
        
    }

    void image_rsense_Cb(const sensor_msgs::ImageConstPtr& msg)
    {


        try
        {
            this->cv_rsense_ptr = cv_bridge::toCvCopy(msg, sensor_msgs::image_encodings::BGR8);
        }
        
        catch (cv_bridge::Exception& e)
        {
            ROS_ERROR("cv_bridge exception: %s", e.what());
            return;
        }
        
    }

    void spCb(bebop_ros::spData sp_topic)
    {
        sp_dat[0] = sp_topic.xpos;
        sp_dat[1] = sp_topic.ypos;
        sp_dat[2] = sp_topic.zpos;

        sp_dat[3] = sp_topic.yaw;
    }

    void pidCb(Twist cmd_msg)
    {
        cmd_vel.linear = cmd_msg.linear;
        cmd_vel.angular = cmd_msg.angular;
    }

    void pnpCb(bebop_ros::rpData pnp_msg)
    {
        pnp_dat = pnp_msg;
    }

    void relCb(bebop_ros::rpData rel_msg)
    {
        rel_dat = rel_msg;
    }

    void kpData_Callback(bebop_ros::kpData kp_topic) 
    {

        for(int i = 0; i < 16; i++)
        {
            kp_array[i] = kp_topic.vert_kp[i];
        }

    }

    void save_data(tf::StampedTransform bebop_transform, tf::StampedTransform target_transform, double sec_now, int& img_count)
    {

            R_anafi.setRotation(bebop_transform.getRotation());
            R_target.setRotation(target_transform.getRotation());
            
            R_anafi.getRPY(roll_a,pitch_a,yaw_a);
            R_target.getRPY(roll_b,pitch_b,yaw_b);

            p_anafi = bebop_transform.getOrigin();
            p_target = target_transform.getOrigin();
            
            sprintf(s, "img%05d.jpg", img_count);


            outputFile  << s << "," 
                        << secs_currrent << ","

                        // Anafi Pose Data
                        << p_anafi[0] << ","
                        << p_anafi[1] << ","
                        << p_anafi[2] << ","

                        << roll_a << ","
                        << pitch_a << ","
                        << yaw_a << ","

                        // Bebop Pose Data
                        << p_target[0] << ","
                        << p_target[1] << ","
                        << p_target[2] << ","

                        << roll_b << ","
                        << pitch_b << ","
                        << yaw_b << ","

                        // Setpoint Data
                        << sp_dat[0] << ","
                        << sp_dat[1] << ","
                        << sp_dat[2] << ","
                        << sp_dat[3] << ","

                        // Vicon relative pose
                        << rel_dat.xrel << ","
                        << rel_dat.yrel << ","
                        << rel_dat.zrel << ","

                        // Estimated relative pose
                        << pnp_dat.xrel << ","
                        << pnp_dat.yrel << ","
                        << pnp_dat.zrel << ","
                        
                        // PID Data 
                        << cmd_vel.linear.x << ","
                        << cmd_vel.linear.y << ","
                        << cmd_vel.linear.z << ","
                        << cmd_vel.angular.z << ","

                        << kp_array[0] << ","
                        << kp_array[1] << ","
                        << kp_array[2] << ","
                        << kp_array[3] << ","
                        << kp_array[4] << ","
                        << kp_array[5] << ","
                        << kp_array[6] << ","
                        << kp_array[7] << ","

                        << kp_array[8] << ","
                        << kp_array[9] << ","
                        << kp_array[10] << ","
                        << kp_array[11] << ","
                        << kp_array[12] << ","
                        << kp_array[13] << ","
                        << kp_array[14] << ","
                        << kp_array[15] 

            <<std::endl;

            img_path = frame_path + s;
            imwrite(img_path, this->cv_ptr->image); 

            sprintf(s, "img_raw_%05d.jpg", img_count);
            img_path = frame_raw_path + s;
            imwrite(img_path, this->cv_raw_ptr->image); 

            if (realsense_activation == "on")
            {
                sprintf(s, "img_realsense_%05d.jpg", img_count);
                img_path = frame_rsense_path + s;
                imwrite(img_path, this->cv_rsense_ptr->image); 
            }

            // cv::imshow(OPENCV_WINDOW, this->cv_ptr->image);
            // cv::waitKey(3);

            img_count++;

            std::cout << "Image Saved: " << img_count << "\n";
    }

};

int main(int argc, char** argv)
{

    ros::init(argc, argv, "bebop_pursuit_data_node");
    ROS_INFO("Visualization Initiated!\n");

    int img_count = 0;
    int &img_count_ref = img_count;

    PursuitData pursuit_data;


    double secs_init, secs_currrent;

    secs_init = ros::Time::now().toSec();

    ros::Rate rate(10);

    // /tf Variables //
    tf::TransformListener listener;

    tf::StampedTransform bebop_transform;
    tf::StampedTransform target_transform;

    while (ros::ok())
	{

        secs_currrent = ros::Time::now().toSec() - secs_init;

        try
        {
            listener.lookupTransform("/map","/vicon/bebop/bebop",ros::Time(0),bebop_transform);
            listener.lookupTransform("/map","/vicon/target/target",ros::Time(0),target_transform);
        }
        catch (tf::TransformException ex) 
        {
            ROS_ERROR("%s",ex.what());
            goto stop;
        }

        if (pursuit_data.cv_ptr && pursuit_data.cv_raw_ptr)
        {
            if(pursuit_data.realsense_activation == "off")
            {
                if(pursuit_data.cv_ptr->image.rows != 720 || pursuit_data.cv_ptr->image.cols != 1280)
                {
                    std::cout << pursuit_data.cv_ptr->image.rows << " " << pursuit_data.cv_ptr->image.cols << "\n";
                    ROS_ERROR("INCORRECT INPUT IMAGE FRAME SIZE!");
                    goto stop;
                }

                pursuit_data.save_data(bebop_transform, target_transform, secs_currrent, img_count_ref);
            }

            else if(pursuit_data.realsense_activation == "on" && pursuit_data.cv_rsense_ptr)
            {
                if(pursuit_data.cv_ptr->image.rows != 720 || pursuit_data.cv_ptr->image.cols != 1280)
                {
                    std::cout << pursuit_data.cv_ptr->image.rows << " " << pursuit_data.cv_ptr->image.cols << "\n";
                    ROS_ERROR("INCORRECT INPUT IMAGE FRAME SIZE!");
                    goto stop;
                }

                pursuit_data.save_data(bebop_transform, target_transform, secs_currrent, img_count_ref);
            }

        }


        stop:
        ros::spinOnce(); 
        rate.sleep();
        
    }

    // ros::spin();
    
    return 0;
}