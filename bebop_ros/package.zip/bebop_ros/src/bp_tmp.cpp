/**
Software License Agreement (BSD)

\file      bp_tmp.cpp
\author   Amir Hossein Ebrahimnezhad <ebrahimnezhad@ualberta.ca>
\maintainer Martin Barczyk <mbarczyk@ualberta.ca>
\copyright Copyright (c) 2023, Mechatronic Systems Lab (University of Alberta), All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that
the following conditions are met:
 * Redistributions of source code must retain the above copyright notice, this list of conditions and the
   following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the
   following disclaimer in the documentation and/or other materials provided with the distribution.
 * Neither the name of Mechatronic Systems Lab nor the names of its contributors may be used to endorse or promote
   products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WAR-
RANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, IN-
DIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

//ROS Headers
#include <ros/ros.h>
#include <geometry_msgs/Twist.h>
#include <geometry_msgs/Pose.h>
#include <geometry_msgs/TransformStamped.h>
#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>
#include <sensor_msgs/image_encodings.h>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>

// Header Files Specific to the project
#include"../include/twistops.hpp" 

#include<tf/transform_listener.h>
#include<tf/tf.h>
#include<tf/transform_datatypes.h>
#include<tf/transform_broadcaster.h>

// Custom Libraries
#include <pulse_generator.h>
#include <pid_ctrl.h>

//Custom Message Declaration 
// #include <anafi_ros/spData.h>

// Header Files Specific to the project


//C++ I/O
#include <iostream>
#include <stdio.h>
#include <string>
#include <sstream>
#include <fstream> 

//Standard headers
#include <time.h>
#include <math.h>



// Global Variables


// CLasses


class NodeClass
{

private:

    // NodeHandle
    ros::NodeHandle nh_;
    ros::NodeHandle private_nh;

    // Image Transport
    image_transport::ImageTransport it_;


    // Publishers
    ros::Publisher twist_pub_;


public:

    // Methods
    void publishCMD(const double* twist_array);

    // Publish Variables
    double secs_init = ros::Time::now().toSec();

    // Paramters
    std::string temp_param;
    geometry_msgs::Twist bebop_cmd;
    geometry_msgs::Pose bebop_pose;

    // Constructor
    NodeClass()
        : private_nh("~"),
          it_(nh_)
    {

        private_nh.getParam("temp_param", temp_param);

        ROS_INFO("Starting Node...\n");
        ROS_INFO("OpenCV version: %s\n",CV_VERSION);

        twist_pub_ = nh_.advertise<geometry_msgs::Twist>("/bebop/cmd_vel",1000);

    }

    // Deconstructor
    ~NodeClass()
    {
        // cv::destroyWindow(OPENCV_WINDOW);
    }
 


};

void NodeClass::publishCMD(const double* twist_array) 
{
    
    bebop_cmd.linear.x = twist_array[0];
    bebop_cmd.linear.y = twist_array[1];
    bebop_cmd.linear.z = twist_array[2];
    bebop_cmd.angular.x = twist_array[3];
    bebop_cmd.angular.y = twist_array[4];
    bebop_cmd.angular.z = twist_array[5];
    twist_pub_.publish(bebop_cmd);
};


void twistPrint(Twist* twistPtr) 
{
    std::cout << "Setpoint X: " << std::fixed << std::setprecision(2) << twistPtr->linear.x << std::endl;
    std::cout << "Setpoint Y: " << std::fixed << std::setprecision(2) << twistPtr->linear.y << std::endl;
    std::cout << "Setpoint Z: " << std::fixed << std::setprecision(2) << twistPtr->linear.z << std::endl;
    std::cout << "Setpoint Yaw: " << std::fixed << std::setprecision(2) << twistPtr->angular.z << std::endl;

}

void timePrint(double t) 
{
std::cout << "Current Time: " << std::fixed << std::setprecision(2) << t << std::endl;
}

int main(int argc, char** argv)
{

    //Initiations
    ros::init(argc, argv, "bebop_temp_node");
    ROS_INFO("Node Initiated!\n");

    geometry_msgs::Pose bebop_pose;

    // Object Declaration
    NodeClass node_class;

    // Frequency and Time
    int f = 10;
    double t_ros = 0;
    double dt_ = (double) 1/f;

    // ROS Rate
    ros::Rate rate(f);

    PulseGenerator x_pulse(2., 2.);

    double pose_sp[6] = {0.5, 0.0, 0.0, 0.0, 0.0, 0.1};

    double k_[] = {10.0, 1.0, 1.0};
    double cmd;

    PIDController x_pid(k_, dt_, 1.0);
    
    while (ros::ok())
	{

        pose_sp[0] = x_pulse.generatePulse(t_ros);
        
        node_class.publishCMD(pose_sp);

    
        cmd = x_pid.compute(1.0 - 0.0);
        std::cout << "CMD: " << cmd << std::endl;

        t_ros += dt_;

        // ROS_INFO("Current time: %f", t_ros);
        // timePrint(t_ros);
        // twistPrint(&node_class.bebop_cmd);

        ros::spinOnce(); 
        rate.sleep();
    }

    
    return 0;
}
