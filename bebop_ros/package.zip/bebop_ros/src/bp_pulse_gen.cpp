/**
Software License Agreement (BSD)

\file      bp_pulse_gen.cpp
\author   Amir Hossein Ebrahimnezhad <ebrahimnezhad@ualberta.ca>
\maintainer Martin Barczyk <mbarczyk@ualberta.ca>
\copyright Copyright (c) 2023, Mechatronic Systems Lab (University of Alberta), All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that
the following conditions are met:
 * Redistributions of source code must retain the above copyright notice, this list of conditions and the
   following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the
   following disclaimer in the documentation and/or other materials provided with the distribution.
 * Neither the name of Mechatronic Systems Lab nor the names of its contributors may be used to endorse or promote
   products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WAR-
RANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, IN-
DIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

//ROS Headers
#include <ros/ros.h>
#include <geometry_msgs/Twist.h>
#include <geometry_msgs/Pose.h>
#include <geometry_msgs/TransformStamped.h>
#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>
#include <sensor_msgs/image_encodings.h>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>

// Header Files Specific to the project
#include"../include/twistops.hpp" 

#include<tf/transform_listener.h>
#include<tf/tf.h>
#include<tf/transform_datatypes.h>
#include<tf/transform_broadcaster.h>

// Custom Libraries
#include <pulse_generator.h>

//Custom Message Declaration 
// #include <anafi_ros/spData.h>

// Header Files Specific to the project


//C++ I/O
#include <iostream>
#include <stdio.h>
#include <string>
#include <sstream>
#include <fstream> 
#include <typeinfo>

//Standard headers
#include <time.h>
#include <math.h>



// Global Variables


// CLasses


class PulseNode
{

private:

    // NodeHandle
    ros::NodeHandle nh_;
    ros::NodeHandle private_nh;

    // Publishers
    ros::Publisher pose_pub_;


public:

    // Methods
    int selectPulseIndex();
    void publishPose(const double* pose_array);

    // Publish Variables
    double secs_init = ros::Time::now().toSec();

    // Paramters
    std::string temp_param;
    geometry_msgs::Pose bebop_cmd_pose;
    std::string pulse_mode, pulse_axis;
    double t_sim, pulse_amp, pulse_width;

    // Constructor
    PulseNode()
        : private_nh("~")
    {

        private_nh.getParam("pulse_mode", pulse_mode);
        private_nh.getParam("t_sim", t_sim);
        private_nh.getParam("axis", pulse_axis);
        private_nh.getParam("pulse_amp", pulse_amp);
        private_nh.getParam("pulse_width", pulse_width);

        ROS_INFO("Starting Node...\n");

        pose_pub_ = nh_.advertise<geometry_msgs::Pose>("/bebop/spData",1000);

    }

};

int PulseNode::selectPulseIndex()
{
    int i = 0;

    if (pulse_axis == "x_axis")
    {
        i = 0;
    }
    
    else if (pulse_axis == "y_axis")
    {
        i = 1;
    }

    else if (pulse_axis == "z_axis")
    {
        i = 2;
    }

    else if (pulse_axis == "yaw_axis")
    {
        i = 5;
    }  

    return i;

};

void PulseNode::publishPose(const double* pose_array) 
{
    
    bebop_cmd_pose.position.x = pose_array[0];
    bebop_cmd_pose.position.y = pose_array[1];
    bebop_cmd_pose.position.z = pose_array[2] + 1.0;
    bebop_cmd_pose.orientation.x = pose_array[3];
    bebop_cmd_pose.orientation.y = pose_array[4];
    bebop_cmd_pose.orientation.z = pose_array[5];
    pose_pub_.publish(bebop_cmd_pose);
};

void printPose(geometry_msgs::Pose* posePtr) 
{
    std::cout << "Setpoint X: " << std::fixed << std::setprecision(2) << posePtr->position.x << std::endl;
    std::cout << "Setpoint Y: " << std::fixed << std::setprecision(2) << posePtr->position.y << std::endl;
    std::cout << "Setpoint Z: " << std::fixed << std::setprecision(2) << posePtr->position.z << std::endl;
    std::cout << "Setpoint Yaw: " << std::fixed << std::setprecision(2) << posePtr->orientation.z << std::endl;

}

void printTime(double t) 
{
    std::cout << "Current Time: " << std::fixed << std::setprecision(2) << t << std::endl;
}


int main(int argc, char** argv)
{

    //Initiations
    ros::init(argc, argv, "bebop_pulse_node");
    ROS_INFO("Node Initiated!\n");

    geometry_msgs::Pose bebop_cmd_pose_dat;

    // Object Declaration
    PulseNode pulse_node;

    // Frequency and Time
    int f = 25;
    double t_ros = 0.;
    double dt_ = (double) 1/f;

    // ROS Rate
    ros::Rate rate(f);

    PulseGenerator pulse_signal(pulse_node.pulse_width, pulse_node.pulse_amp);

    double pose_sp[6] = {0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
    int pulse_index = pulse_node.selectPulseIndex();

    
    while (ros::ok())
	{

        pose_sp[pulse_index] = pulse_signal.generatePulse(t_ros); // Retrieve Generated Pulse
        pulse_node.publishPose(pose_sp); // Publish Pose with Generated Pulse


        ros::spinOnce(); 
        rate.sleep();
        
        t_ros += dt_;

        // ROS_INFO("Current time: %f", t_ros);
        printTime(t_ros);
        printPose(&pulse_node.bebop_cmd_pose);

    }

    
    return 0;
}