# bebop_ros

This package is a fork of bebop_autonomy (SFU) and bebop2-ros (UofA) packages. The main goal of developing this package has been the implemenation of real-time vision-based pursuit algorithms for UAVs. Moreover, there are necessary tools in this package for online tuning of PID flight controllers, data acqusition, pose estimation and pursuit. The following instructions entail the necessary installations and commands to run the package and launch files. 


![Alt Text](./repo/frame/img_graph.jpg)

## Table of Contents

- [Features](#features)
- [Installation](#installation)
- [Usage](#usage)
- [Contributing](#contributing)
- [License](#license)

## Features

- List the key features and functionalities of your project.
- Provide a high-level overview of what your project does.

## Installation

### Ubuntu 20.04

Install Ubuntu 20.04 dekstop image. Follow instructions on [ubuntu.com](https://releases.ubuntu.com/focal/). 


### ROS Noetic

Install ROS noetic, follow instructions on [wiki.ros.org](http://wiki.ros.org/noetic/Installation/Ubuntu). 

After installing ROS, create catkin workspace by following [ROS documenations](http://wiki.ros.org/ROS/Tutorials/InstallingandConfiguringROSEnvironment). 

### CUDA

NVIDIA drivers and CUDA are required for training and running deep learning algorithms and networks. Installing CUDA could be a headache! These instructions are set for NVIDIA RTX 3090 and Ubuntu 20. 

```
sudo apt-get install nvidia-driver-450
```

After installing the driver, you need to install CUDA. Go to [CUDA Toolkit 11.2 Downloads](https://developer.nvidia.com/cuda-11.2.0-download-archive?target_os=Linux&target_arch=x86_64&target_distro=Ubuntu&target_version=1804&target_type=runfilelocal). Choose Linux/x86_64/Ubuntu/20.04/runfile(local) and follow Base installer instructions:

```
wget https://developer.download.nvidia.com/compute/cuda/11.2.0/local_installers/cuda_11.2.0_460.27.04_linux.run```
```

```
sudo sh cuda_11.2.0_460.27.04_linux.run
```

### Pytorch

Pytorch is a deep learning library which is necessary for implementing keypoint-RCNN networks and 3D bounding box estimation. Install the right Pytorch version using pip as:

```
pip install torch==1.9.0+cu111 torchvision==0.10.0+cu111 torchaudio==0.9.0 -f
```

Now run this code on Python to make sure CUDA and Torch are installed:

```
import torch

cuda_version = torch.version.cuda
print("CUDA version:", cuda_version)
```

### vicon_bridge

Install vicon_bridge to set up a pipeline between Vicon Tracker and ROS.

```
cd ~/catkin_ws/src/
git clone https://github.com/ethz-asl/vicon_bridge
rosdep install -r --from-paths vicon_bridge/
cd ~/catkin_ws/
```

Before making build catkin build files, it is required to replace the Vicon SDK on the package. Visit [Vicon Datastream SDK](https://www.vicon.com/software/datastream-sdk/) and download the latest sdk, extract the files and replace ViconDataStreamSDK_CPPTest.cpp and DataStreamClient.h with the latest downloaded ones in /vicon_brdige/src filder. Now run:


```
catkin_make
```

Now change the default IP in vicon.launch file to that of the computer that has tracker installed:


```
<arg
    name="ip"
    default="129.128.134.50"
/><!--IP address of the computer running tracker-->
```

Now run Vicon Tracker on Windows computer and run the vicon.launch file to make sure Vicon is connected:

```
roslaunch vicon_bridge vicon.launch
```

### bebop_autonomy

bebop_autonomy is core package which includes parrot sdk and necessary launch files for connecting to bebop drone and establishing video stream pipelines. Clone the repository by running:

```
cd ~/catkin_ws/src/
```

```
git clone https://github.com/AutonomyLab/bebop_autonomy.git src/bebop_autonomy
```

```
cd ~/catkin_ws/
```

### parrotsdk

For ROS Noetic, the Parrot SDK should be installed seperately. Follow the instructions on [parrot_arsdk](https://github.com/antonellabarisic/parrot_arsdk/tree/noetic_dev) for installation.

### bebop_ros

Eventually, you need to clone bebop_ros package from github through ssh:

```
cd ~/catkin_ws/src/
git clone git@github.com:roboticswithamir/bebop_ros.git
``` 

Then, catkin_make the whole workspace:

```
cd ~/catkin_ws/
catkin_make
```

## Usage

### Manual Control

For manual control of bebop, we need to launch the bebop driver first:

```
roslaunch bebop_ros bebop_nodelet.launch 
```

Now run the manual control ROS node:

```
rosrun bebop_ros pursuer_manual_ctrl
```

For sending commands, click on the stream feed screen and use the following key commands:

```
    s: Left
    f: Right
    e: Forwards
    d: Backwards
 
    w: Rotate Left
    r: Rotate Right
 
    q: Up
    a: Down
 
    y: Takeoff
    h: Land
 
    x: Quit
```

### Pulse Generator


For generating a pulse on a desired axis with desired amplitude and pulse time, you can simply run:

```
roslaunch bebop_ros bebop_pulse.launch pulse_width:=10.0 pulse_amp:=5.0
```

To specify the pulse_width and pulse_amp you can either set them in terminal or you can change the launch file arguemtns:

```
<arg
    name="pulse_amp"
    default="2.0" 
/> <!-- Choosing command value -->
```

To activate the pulse, it is needed to set drone_activation argument to "on" on launch file and manually click on PID activation on the prompted "PID Parameters" GUI.


### PID Tuning

The controller is already tuned with the embedded gains in bp_pid.cpp node. However, for retuning the flight controller in real-time, first run Vicon:

```
roslaunch vicon_bridge vicon.launch
```

Make sure to calibrate bebop to transform COM into camera by running this command in a different terminal in this experiment and the future ones:

```
rosrun vicon_bridge calibrate bebop bebop 0.04
```

Then:

```
roslaunch bebop_ros bebop_pid.launch pulse_width:=10.0 pulse_amp:=0.5
```

For having visuals, run rqt and add plot plugins:

```
rqt
```

<br />


### Data Acquisition

The objective in this section is to generate the 3D bounding box keypoints by flying two bebop drones as pursuer and target. Run Vicon tracker and define two objects: pursuer as 'bebop' and the second drone as 'target'. Connect the first one to Ubuntu wifi and run vicon_bridge and bebop_nodelet launch files:


```
roslaunch vicon_bridge vicon.launch
roslaunch bebop_ros bebop_nodelet.launch 
```

And calibrate the pursuer:

```
rosrun vicon_bridge calibrate bebop bebop 0.04
```

Now go to repo/codes folder and run reset_dataset.py

```
cd ~/catkin_ws/src/bebop_ros/repo/codes/
python reset_dataset.py
```

Make sure all Python files are exetubale by running the following code for instance:

```
chmod +x reset_dataset.py
```

Now run data acquisition launch file:

```
roslaunch bebop_ros bebop_data_acq.launch 
```

And now run manual control for sending take off command:

```
rosrun bebop_ros pursuer_manual_ctrl
```

You could keep running the bebop manually or activate PID for a fixed position to generate the dataset. After terminating the ROS you shall see the geenrated frames in ~/catkin_ws/src/bebop_ros/repo/dataset/data and csv data in /repo/dataset/csv/img_rel_pose_offset.csv

<br />


### Offset Removal

The generated keypoints come with an offset in 3D bounding box placement on image plane. 

![Alt Text](./repo/frame/frame_offset.jpg)


To remove the offset, we use a trained Mask-RCNN network for detecting the drone as a 2D bounding box and use it as an anchor for relocating the 3D bounding box accordingly. To do so simply open offset_romval.py from repo/codes and change dataSave = True, then:

```
cd ~/catkin_ws/src/bebop_ros/repo/codes/
python offset_removal.py
```

Once the offset removal is finished, a new .csv file titled as "img_rel_pose.csv" will be saved in /repo/csv folder which contains the calibrated keypoints.


### Annotation Generation

Torchvision supports a specific format for train and test datasets which follows .json files as annotation files. Run annotation_gen.ipynb to generate the required annotation files. Change data_num variable to set your desired number of train/test frames in rcnn folder. A sample .json keypoint annotation looks as follows:

```
{"bboxes": [[477, 207, 730, 273]], "keypoints": [[[[526, 255, 1], [679, 253, 1], [679, 210, 1], [526, 211, 1], [515, 273, 1], [695, 271, 1], [695, 220, 1], [515, 222, 1]]]]}
```



### RCNN Training

The backbone of RCNN training is based on [Pytorch vision library](https://github.com/pytorch/vision/tree/main/references/detection) and keypointrcnn_resnet50_fpn model. Open rcnn_train.py file and change num_epochs to your desired number of keypoints. Then:

```
python rcnn_train.py
``` 

After the training is finished, the torch model is saved as bebop_rcnn.pt in codes folder.

<br />

## Development Team

Author: <br />
Amir Ebrahimnezhad (Mechatronic Systems Lab, University of Alberta) 

Maintainer: <br />
Dr. Martin Barczyk (Mechatronic Systems Lab, University of Alberta)


<!-- 1. Provide examples and instructions on how to use your project.
2. Include code snippets or command-line examples to illustrate usage.
3. You can also include screenshots or GIFs to showcase the project in action. -->

<!-- ## Contributing

1. State guidelines for contributing to your project.
2. Explain how other developers can contribute code, report issues, or suggest improvements.
3. Provide instructions on how to set up the development environment and run tests. -->