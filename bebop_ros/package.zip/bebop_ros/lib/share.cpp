/*
 * Contains functions used in both UAVDetect.cpp and UAVFollow.cpp
 *
 * Author:      Adam Casey,     acasey@ualberta.ca
 * Maintainer:  Martin Barczyk, mbarczyk@ualberta.ca
 */

#include <chrono>
#include <stdio.h>

#include <ros/ros.h>

#include <geometry_msgs/Twist.h>

#include "../include/colour.h"
#include "../include/twistops.hpp"

//If the command is nonzero, publishes for `time` milliseconds
void pubTime (Twist cmd, ros::Publisher pub, long time){
    if (!(cmd == blank)){
        using namespace std::chrono;

        //Start time
        auto startPrecise = high_resolution_clock::now();

        while (duration_cast<milliseconds>(high_resolution_clock::now() - startPrecise).count() < time){
            pub.publish(cmd);
        }
    }

    pub.publish(blank);
}
