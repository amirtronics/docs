/*
 * Contains functions used to do arithmetic on the struct geometry_msgs::Twist
 * Also does a `typedef` to shorten geometry_msgs::Twist to just Twist, for the sake of convenience 
 * and short lines.
 * Author:      Adam Casey,     acasey@ualberta.ca
 * Maintainer:  Martin Barczyk, mbarczyk@ualberta.ca
 */

#include <geometry_msgs/Twist.h>

typedef geometry_msgs::Twist Twist;

//Convenient arithmetic for Twist
//These three are very similiar, and a functions should be written to conserve code 
//by condensing these.TODO 
Twist operator+(Twist left, Twist right){
    Twist retVal;
    
    retVal.linear.x     = left.linear.x     + right.linear.x;
    retVal.linear.y     = left.linear.y     + right.linear.y;
    retVal.linear.z     = left.linear.z     + right.linear.z;
    retVal.angular.x    = left.angular.x    + right.angular.x;
    retVal.angular.y    = left.angular.y    + right.angular.y;
    retVal.angular.z    = left.angular.z    + right.angular.z;
        
        return retVal;
}

Twist operator-(Twist left, Twist right){
    Twist retVal;
    
    retVal.linear.x     = left.linear.x     - right.linear.x;
    retVal.linear.y     = left.linear.y     - right.linear.y;
    retVal.linear.z     = left.linear.z     - right.linear.z;
    retVal.angular.x    = left.angular.x    - right.angular.x;
    retVal.angular.y    = left.angular.y    - right.angular.y;
    retVal.angular.z    = left.angular.z    - right.angular.z;
        
        return retVal;
}

template <typename T>
Twist operator/(Twist twist, T divisor){
    Twist retVal;
    
    retVal.linear.x     = twist.linear.x    /divisor;
    retVal.linear.y     = twist.linear.y    /divisor;
    retVal.linear.z     = twist.linear.z    /divisor;
    retVal.angular.x    = twist.angular.x   /divisor;
    retVal.angular.y    = twist.angular.y   /divisor;
    retVal.angular.z    = twist.angular.z   /divisor;
        
    return retVal;
}
 
bool operator==(Twist left, Twist right){
    return  left.linear.x == right.linear.x &&
            left.linear.y == right.linear.y &&
            left.linear.z == right.linear.z &&
            left.angular.x == right.angular.x &&
            left.angular.y == right.angular.y &&
            left.angular.z == right.angular.z;
}
