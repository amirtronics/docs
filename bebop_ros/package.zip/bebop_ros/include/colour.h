/*
 * Author:      Adam Casey,     acasey@ualberta.ca
 * Maintainer:  Martin Barczyk, mbarczyk@ualberta.ca
 */

//Text colours for debug
#define ANSI_RED         "\x1b[31m"
#define ANSI_GREEN       "\x1b[32m"
#define ANSI_YELLOW      "\x1b[33m"
#define ANSI_BLUE        "\x1b[34m"
#define ANSI_MAGENTA     "\x1b[35m"
#define ANSI_CYAN        "\x1b[36m"
#define ANSI_RESET       "\x1b[0m"

#define ANSI_BOLD   "\033[1m"
#define ANSI_NORMAL "\033[0m"
