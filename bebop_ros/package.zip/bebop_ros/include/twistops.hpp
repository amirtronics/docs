/*
 * Header for twistops.cpp
 *
 * Author:      Adam Casey,     acasey@ualberta.ca
 * Maintainer:  Martin Barczyk, mbarczyk@ualberta.ca
 */

#ifndef __twistops_hpp__
    #define __twistops_hpp__

    #include <geometry_msgs/Twist.h>

    typedef geometry_msgs::Twist Twist;

    const Twist blank;

    Twist operator+(Twist left, Twist right);
    Twist operator-(Twist left, Twist right);
    template<typename T>
    Twist operator/(Twist twist, T divisor);
    bool operator==(Twist left, Twist right);
#endif
