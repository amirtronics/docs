
//ROS Headers
#include <ros/ros.h>
#include <geometry_msgs/Twist.h>
#include <geometry_msgs/TransformStamped.h>
#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>
#include <sensor_msgs/image_encodings.h>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>

#include<tf/transform_listener.h>
#include<tf/tf.h>
#include<tf/transform_datatypes.h>
#include<tf/transform_broadcaster.h>

//Custom Message Declaration 
// #include <anafi_ros/spData.h>

// Header Files Specific to the project


//C++ I/O
#include <iostream>
#include <stdio.h>
#include <string>
#include <sstream>
#include <fstream> 

//Standard headers
#include <time.h>
#include <math.h>



// Global Variables


// CLasses


class NodeClass
{

    // NodeHandle
    ros::NodeHandle nh_;
    ros::NodeHandle private_nh;

    // Image Transport
    image_transport::ImageTransport it_;

    // Subscribers
    ros::Subscriber temp_sub;

    // Publishers
    ros::Publisher temp_pub;


    

public:

    // Publish Variables
    double secs_init = ros::Time::now().toSec();

    // Paramters
    std::string temp_param;


    // Constructor
    NodeClass()
        : private_nh("~"),
          it_(nh_)
    {

        private_nh.getParam("temp_param", temp_param);

        ROS_INFO("Starting Node...\n");
        ROS_INFO("OpenCV version: %s\n",CV_VERSION);

    }

    // Deconstructor
    ~NodeClass()
    {
        // cv::destroyWindow(OPENCV_WINDOW);
    }
 
    
    void temp_func()
    {

        
    }

};

int main(int argc, char** argv)
{

    //Initiations
    ros::init(argc, argv, "bebop_temp_node");
    ROS_INFO("Node Initiated!\n");

    // Object Declaration
    NodeClass temp_class;

    // ROS Rate
    ros::Rate rate(10);

    // TF
    tf::TransformListener listener;
    tf::StampedTransform bebop_transform;


    while (ros::ok())
	{

        try
        {
            listener.lookupTransform("/map","/vicon/bebop/bebop",ros::Time(0),bebop_transform);
        }

        catch (tf::TransformException ex) 
        {
            ROS_ERROR("%s",ex.what());
        }

        ros::spinOnce(); 
        rate.sleep();
        
    }


    
    return 0;
}